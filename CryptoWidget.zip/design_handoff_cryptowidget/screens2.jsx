/* screens2.jsx — Search, Portfolio, Alerts, WidgetSettings + Sheet/Switch */

function Switch({ on, onChange }) {
  return (
    <div className="press" onClick={() => onChange(!on)} style={{
      width: 46, height: 27, borderRadius: 27, padding: 3, cursor: "pointer", flexShrink: 0,
      background: on ? "var(--accent)" : "var(--surface-2)", border: "1px solid var(--border)",
      transition: "background .18s", display: "flex", alignItems: "center",
      justifyContent: on ? "flex-end" : "flex-start",
    }}>
      <div style={{ width: 21, height: 21, borderRadius: 21, background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.4)" }} />
    </div>
  );
}

function Sheet({ title, onClose, children }) {
  return (
    <div onClick={onClose} style={{ position: "absolute", inset: 0, zIndex: 40, display: "flex", flexDirection: "column", justifyContent: "flex-end", background: "rgba(0,0,0,0.55)", backdropFilter: "blur(2px)" }}>
      <div onClick={(e) => e.stopPropagation()} className="sheet-in" style={{ background: "var(--bg)", borderTop: "1px solid var(--border-strong)", borderRadius: "22px 22px 0 0", padding: "8px 16px 24px", maxHeight: "82%", overflow: "auto" }}>
        <div style={{ width: 38, height: 4, borderRadius: 4, background: "var(--border-strong)", margin: "8px auto 14px" }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 18, fontWeight: 700, color: "var(--text)" }}>{title}</div>
          <div className="press" onClick={onClose} style={{ cursor: "pointer", padding: 4 }}><Icon name="close" size={22} color="var(--text-3)" /></div>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Search ───────────────────────────────────────────────────────────
function Search({ watchlist, currency, onBack, onOpenAsset, onToggleWatch }) {
  const [q, setQ] = React.useState("");
  const all = window.DATA.ASSETS;
  const ql = q.trim().toLowerCase();
  const filtered = ql ? all.filter((a) => a.name.toLowerCase().includes(ql) || a.ticker.toLowerCase().includes(ql)) : all;
  const groups = window.DATA.CATEGORIES.filter((c) => c.id !== "vse").map((c) => ({
    ...c, items: filtered.filter((a) => a.category === c.id),
  })).filter((g) => g.items.length);

  return (
    <div>
      <div style={{ position: "sticky", top: 0, zIndex: 5, background: "var(--bg)", borderBottom: "1px solid var(--border)", padding: "12px 16px", display: "flex", alignItems: "center", gap: 10 }}>
        <div className="press" onClick={onBack} style={{ cursor: "pointer", padding: 4, margin: -4 }}><Icon name="back" size={24} color="var(--text)" /></div>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 9, background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: "var(--chip-radius)", padding: "9px 12px" }}>
          <Icon name="search" size={18} color="var(--text-3)" />
          <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Hledat aktivum, ticker…" style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "var(--text)", fontFamily: "var(--font-ui)", fontSize: 15 }} />
          {q && <div className="press" onClick={() => setQ("")} style={{ cursor: "pointer" }}><Icon name="close" size={16} color="var(--text-3)" /></div>}
        </div>
      </div>

      <div style={{ paddingBottom: 20 }}>
        {groups.map((g) => (
          <div key={g.id}>
            <SectionLabel style={{ padding: "16px 16px 6px" }}>{g.label}</SectionLabel>
            {g.items.map((a) => {
              const inW = watchlist.includes(a.id);
              return (
                <div key={a.id} className="press row-sep" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 16px" }}>
                  <div onClick={() => onOpenAsset(a.id)} style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, cursor: "pointer", minWidth: 0 }}>
                    <AssetIcon asset={a} size={36} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 14, color: "var(--text)" }}>{a.ticker}</div>
                      <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)" }}>{a.name}</div>
                    </div>
                  </div>
                  <div style={{ textAlign: "right", marginRight: 4 }}>
                    <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--text)" }}>{window.FMT.price(a.price, currency)}</div>
                    <Change value={a.change24h} size={11} arrow={false} />
                  </div>
                  <div className="press" onClick={() => onToggleWatch(a.id)} style={{ cursor: "pointer", padding: 6 }}>
                    <Icon name={inW ? "starFill" : "star"} size={22} color={inW ? "var(--accent)" : "var(--text-3)"} />
                  </div>
                </div>
              );
            })}
          </div>
        ))}
        {groups.length === 0 && <div style={{ padding: 48, textAlign: "center", color: "var(--text-3)", fontFamily: "var(--font-ui)" }}>Nic nenalezeno pro „{q}“</div>}
      </div>
    </div>
  );
}

// ── Portfolio ────────────────────────────────────────────────────────
function PortfolioScreen({ holdings, currency, onBack, onOpenAsset, density, onAdd }) {
  return <PortfolioInner holdings={holdings} currency={currency} onBack={onBack} onOpenAsset={onOpenAsset} density={density} onAdd={onAdd} />;
}
function Portfolio({ holdings, currency, onBack, onOpenAsset, density, onAdd }) {
  return <PortfolioInner holdings={holdings} currency={currency} onBack={onBack} onOpenAsset={onOpenAsset} density={density} onAdd={onAdd} />;
}
function PortfolioInner({ holdings, currency, onBack, onOpenAsset, density, onAdd }) {
  const rows = holdings.map((h) => {
    const a = window.DATA.byId[h.id];
    const value = a.price * h.qty;
    const cost = h.avg * h.qty;
    const pl = value - cost;
    const plPct = (pl / cost) * 100;
    return { a, h, value, cost, pl, plPct };
  });
  const total = rows.reduce((s, r) => s + r.value, 0);
  const totalCost = rows.reduce((s, r) => s + r.cost, 0);
  const totalPl = total - totalCost;
  const totalPlPct = (totalPl / totalCost) * 100;
  const dayChange = rows.reduce((s, r) => s + r.value * (r.a.change24h / 100), 0);
  rows.sort((x, y) => y.value - x.value);

  return (
    <div>
      <TopBar title="Portfolio" big right={<><IconBtn name="plus" color="var(--accent)" onClick={onAdd} /><IconBtn name="dots" /></>} />
      <div style={{ padding: "14px 16px 0" }}>
        <Card pad={18}>
          <SectionLabel>Celková hodnota</SectionLabel>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 34, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em", marginTop: 6 }}>{window.FMT.price(total, currency, currency === "CZK" ? 0 : 2)}</div>
          <div style={{ display: "flex", gap: 14, marginTop: 8 }}>
            <div><span style={{ fontFamily: "var(--font-ui)", fontSize: 11.5, color: "var(--text-3)" }}>Dnes </span><span style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 600, color: dayChange >= 0 ? "var(--up)" : "var(--down)" }}>{window.FMT.signedPrice(dayChange, currency)}</span></div>
            <div><span style={{ fontFamily: "var(--font-ui)", fontSize: 11.5, color: "var(--text-3)" }}>Celkem </span><span style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 600, color: totalPl >= 0 ? "var(--up)" : "var(--down)" }}>{window.FMT.signedPrice(totalPl, currency)} ({window.FMT.pct(totalPlPct)})</span></div>
          </div>
          {/* allocation bar */}
          <div style={{ display: "flex", height: 8, borderRadius: 4, overflow: "hidden", marginTop: 16, gap: 2 }}>
            {rows.map((r) => <div key={r.a.id} style={{ width: (r.value / total) * 100 + "%", background: r.a.color }} />)}
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 14px", marginTop: 10 }}>
            {rows.map((r) => (
              <div key={r.a.id} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <span style={{ width: 8, height: 8, borderRadius: 8, background: r.a.color }} />
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-2)" }}>{r.a.ticker} {((r.value / total) * 100).toFixed(0)} %</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <SectionLabel style={{ padding: "20px 16px 6px" }}>Pozice</SectionLabel>
      {rows.length === 0 && <EmptyPortfolio onAdd={onAdd} />}
      <div style={{ paddingBottom: 24 }}>
        {rows.map((r) => (
          <div key={r.a.id} className="press row-sep" onClick={() => onOpenAsset(r.a.id)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", cursor: "pointer" }}>
            <AssetIcon asset={r.a} size={38} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 14.5, color: "var(--text)" }}>{r.a.ticker}</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--text-3)" }}>{window.FMT.num(r.h.qty, r.h.qty < 1 ? 4 : (r.h.qty > 100 ? 0 : 2))} {r.a.ticker}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 600, color: "var(--text)" }}>{window.FMT.price(r.value, currency, currency === "CZK" ? 0 : 2)}</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, fontWeight: 600, color: r.pl >= 0 ? "var(--up)" : "var(--down)" }}>{window.FMT.pct(r.plPct)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Alerts ───────────────────────────────────────────────────────────
function AlertSheet({ presetAsset, onClose, onSave }) {
  const [asset, setAsset] = React.useState(presetAsset || "BTC");
  const [op, setOp] = React.useState(">");
  const a = window.DATA.byId[asset];
  const [target, setTarget] = React.useState(Math.round(a.price));
  const popular = ["BTC", "ETH", "SOL", "XAU", "DOGE", "SPX"];
  return (
    <Sheet title="Nový cenový alert" onClose={onClose}>
      <SectionLabel style={{ marginBottom: 8 }}>Aktivum</SectionLabel>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
        {popular.map((id) => {
          const act = id === asset;
          return <div key={id} className="press" onClick={() => { setAsset(id); setTarget(Math.round(window.DATA.byId[id].price)); }} style={{ padding: "8px 14px", borderRadius: "var(--chip-radius)", cursor: "pointer", fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 13, background: act ? "var(--accent)" : "var(--surface)", color: act ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${act ? "var(--accent)" : "var(--border)"}` }}>{id}</div>;
        })}
      </div>
      <SectionLabel style={{ marginBottom: 8 }}>Podmínka</SectionLabel>
      <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
        {[[">", "Cena nad"], ["<", "Cena pod"]].map(([o, l]) => (
          <div key={o} className="press" onClick={() => setOp(o)} style={{ flex: 1, textAlign: "center", padding: "11px 0", borderRadius: "var(--radius-sm)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 600, fontSize: 14, background: op === o ? "var(--surface-2)" : "var(--surface)", color: op === o ? "var(--text)" : "var(--text-3)", border: `1px solid ${op === o ? "var(--border-strong)" : "var(--border)"}` }}>{l}</div>
        ))}
      </div>
      <SectionLabel style={{ marginBottom: 8 }}>Cílová cena (USD)</SectionLabel>
      <input type="number" value={target} onChange={(e) => setTarget(Number(e.target.value))} style={{ width: "100%", boxSizing: "border-box", background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-sm)", padding: "13px 14px", color: "var(--text)", fontFamily: "var(--font-mono)", fontSize: 18, fontWeight: 600, outline: "none", marginBottom: 6 }} />
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)", marginBottom: 20 }}>Aktuálně: <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-2)" }}>{window.FMT.price(a.price, "USD")}</span></div>
      <div className="press" onClick={() => onSave({ asset, op, target })} style={{ textAlign: "center", padding: 15, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 15 }}>Vytvořit alert</div>
    </Sheet>
  );
}

function Alerts({ alerts, currency, presetAsset, onBack, onToggle, onDelete, onAdd, openSheet, setOpenSheet }) {
  return (
    <div>
      <TopBar title="Alerty" big onBack={onBack} right={<IconBtn name="plus" color="var(--accent)" onClick={() => setOpenSheet(true)} />} />
      <div style={{ padding: "8px 0 20px" }}>
        {alerts.length === 0 && (
          <div style={{ padding: "60px 32px", textAlign: "center" }}>
            <div style={{ display: "inline-flex", padding: 16, borderRadius: 100, background: "var(--surface)", border: "1px solid var(--border)", marginBottom: 14 }}><Icon name="bell" size={28} color="var(--text-3)" /></div>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 15, color: "var(--text-2)" }}>Zatím žádné alerty</div>
          </div>
        )}
        {alerts.map((al) => {
          const a = window.DATA.byId[al.asset];
          return (
            <div key={al.id} className="row-sep" style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px" }}>
              <AssetIcon asset={a} size={38} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "var(--font-ui)", fontSize: 14.5, color: "var(--text)" }}>
                  <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{a.ticker}</span> {al.op === ">" ? "nad" : "pod"} <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{window.FMT.price(al.target, currency)}</span>
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: al.triggered ? "var(--up)" : "var(--text-3)", marginTop: 2 }}>
                  {al.triggered ? "✓ Spuštěno · 9:12" : (al.active ? "Aktivní · čeká na splnění" : "Pozastaveno")}
                </div>
              </div>
              <div className="press" onClick={() => onDelete(al.id)} style={{ cursor: "pointer", padding: 6 }}><Icon name="trash" size={18} color="var(--text-3)" /></div>
              <Switch on={al.active} onChange={() => onToggle(al.id)} />
            </div>
          );
        })}
      </div>
      {openSheet && <AlertSheet presetAsset={presetAsset} onClose={() => setOpenSheet(false)} onSave={(data) => { onAdd(data); setOpenSheet(false); }} />}
    </div>
  );
}

// ── Widget settings ──────────────────────────────────────────────────
function WidgetSettings({ config, setConfig, accent, currency, fng, watchlist, onBack }) {
  const [size, setSize] = React.useState("large");
  const toggleAsset = (id) => {
    const has = config.assets.includes(id);
    const next = has ? config.assets.filter((x) => x !== id) : [...config.assets, id];
    if (next.length === 0) return;
    setConfig({ ...config, assets: next });
  };
  const cap = size === "small" ? 1 : size === "medium" ? 3 : 5;
  return (
    <div>
      <TopBar title="Nastavení widgetu" onBack={onBack} />
      {/* preview on wallpaper */}
      <div style={{ background: "radial-gradient(120% 90% at 60% 0%, #1a2742, #0a0e16)", padding: "26px 16px", display: "flex", justifyContent: "center", borderBottom: "1px solid var(--border)" }}>
        <Widget size={size} config={config} accent={accent} currency={currency} fng={fng} onOpen={() => {}} />
      </div>

      <div style={{ padding: "18px 16px 0" }}>
        <SectionLabel style={{ marginBottom: 8 }}>Velikost</SectionLabel>
        <div style={{ display: "flex", gap: 8 }}>
          {[["small", "Malý 2×2"], ["medium", "Střední 4×2"], ["large", "Velký 4×4"]].map(([s, l]) => (
            <div key={s} className="press" onClick={() => setSize(s)} style={{ flex: 1, textAlign: "center", padding: "11px 0", borderRadius: "var(--radius-sm)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 600, fontSize: 12.5, background: size === s ? "var(--accent)" : "var(--surface)", color: size === s ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${size === s ? "var(--accent)" : "var(--border)"}` }}>{l}</div>
          ))}
        </div>
      </div>

      <div style={{ padding: "20px 16px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <SectionLabel>Zobrazená aktiva</SectionLabel>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>vyber až {cap}</span>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {watchlist.map((id) => {
            const a = window.DATA.byId[id];
            const on = config.assets.includes(id);
            return (
              <div key={id} className="press" onClick={() => toggleAsset(id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 12px", borderRadius: "var(--chip-radius)", cursor: "pointer", background: on ? "var(--accent)" : "var(--surface)", color: on ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${on ? "var(--accent)" : "var(--border)"}`, fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 13 }}>
                {on && <Icon name="check" size={14} color="var(--accent-ink)" />} {a.ticker}
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ padding: "20px 16px 0" }}>
        <Card pad={4}>
          {[["showFng", "Zobrazit Fear & Greed", config.showFng !== false]].map(([k, l, v]) => (
            <div key={k} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 12px" }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 14.5, color: "var(--text)" }}>{l}</span>
              <Switch on={v} onChange={(nv) => setConfig({ ...config, [k]: nv })} />
            </div>
          ))}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 12px", borderTop: "1px solid var(--border)" }}>
            <span style={{ fontFamily: "var(--font-ui)", fontSize: 14.5, color: "var(--text)" }}>Automatická aktualizace</span>
            <Switch on={true} onChange={() => {}} />
          </div>
        </Card>
      </div>

      <div style={{ padding: "20px 16px 28px" }}>
        <div className="press" onClick={onBack} style={{ textAlign: "center", padding: 15, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 15 }}>Přidat na plochu</div>
      </div>
    </div>
  );
}

Object.assign(window, { Search, Portfolio, PortfolioScreen, PortfolioInner, Alerts, WidgetSettings, AlertSheet, Switch, Sheet });
