/* widgets.jsx — Android home-screen launcher + home widgets (3 sizes) */

// Small mini-row used inside medium/large widgets
function WRow({ a, accent, currency, showSpark = true }) {
  const up = a.change24h >= 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
      <div style={{
        width: 24, height: 24, borderRadius: 24, flexShrink: 0, display: "flex",
        alignItems: "center", justifyContent: "center", background: a.color + "26",
        border: `1px solid ${a.color}55`, color: a.color,
        fontFamily: "var(--font-mono)", fontSize: 9, fontWeight: 700,
      }}>{a.ticker.length > 4 ? a.ticker.slice(0, 3) : a.ticker.slice(0, 1)}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 12.5, color: "#fff", width: 44 }}>{a.ticker}</div>
      {showSpark && <div style={{ flex: 1, opacity: 0.9 }}><Sparkline closes={a.series["1D"].closes} color={up ? "#16c784" : "#ea3943"} width={48} height={18} fill={false} sw={1.4} /></div>}
      <div style={{ textAlign: "right", flex: showSpark ? "none" : 1 }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 12.5, color: "#fff", fontWeight: 600 }}>{window.FMT.price(a.price, currency)}</div>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, color: up ? "#16c784" : "#ea3943", fontWeight: 600 }}>{window.FMT.pct(a.change24h)}</div>
      </div>
    </div>
  );
}

function FngMini({ fng, size = 40 }) {
  const col = window.DATA.fngColor(fng.value);
  const r = size / 2 - 3;
  const c = 2 * Math.PI * r;
  const off = c * (1 - fng.value / 100);
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#ffffff1a" strokeWidth="3" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={col} strokeWidth="3" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontSize: size * 0.3, fontWeight: 700, color: col }}>{fng.value}</div>
    </div>
  );
}

const WIDGET_BG = "linear-gradient(155deg, rgba(20,24,31,0.82), rgba(10,12,16,0.88))";

function WidgetShell({ children, onOpen, h }) {
  return (
    <div onClick={onOpen} className="press" style={{
      background: WIDGET_BG, backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)",
      border: "1px solid rgba(255,255,255,0.1)", borderRadius: 24, padding: 14,
      boxShadow: "0 8px 24px rgba(0,0,0,0.35)", cursor: "pointer", height: h,
      boxSizing: "border-box", display: "flex", flexDirection: "column", overflow: "hidden",
    }}>{children}</div>
  );
}

function WidgetHeader({ accent, right }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <div style={{ width: 16, height: 16, borderRadius: 5, background: accent, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: 6, height: 6, borderRadius: 2, background: "#fff" }} />
        </div>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, fontWeight: 700, color: "#fff", letterSpacing: "0.02em" }}>CryptoWidget</span>
      </div>
      {right}
    </div>
  );
}

function Widget({ size, config, accent, currency, fng, onOpen }) {
  const ids = config.assets;
  const assets = ids.map((id) => window.DATA.byId[id]).filter(Boolean);

  if (size === "small") {
    const a = assets[0] || window.DATA.byId.BTC;
    const up = a.change24h >= 0;
    return (
      <div style={{ width: 168 }}>
        <WidgetShell onOpen={onOpen} h={168}>
          <WidgetHeader accent={accent} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "#fff", fontWeight: 700 }}>{a.ticker}</span>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{a.name}</span>
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 23, color: "#fff", fontWeight: 700, marginTop: 4, letterSpacing: "-0.02em" }}>{window.FMT.price(a.price, currency)}</div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: up ? "#16c784" : "#ea3943", fontWeight: 600 }}>{window.FMT.pct(a.change24h)} · 24h</div>
          <div style={{ flex: 1 }} />
          <Sparkline closes={a.series["1D"].closes} color={up ? "#16c784" : "#ea3943"} width={140} height={36} />
        </WidgetShell>
      </div>
    );
  }

  if (size === "medium") {
    return (
      <div style={{ width: 352 }}>
        <WidgetShell onOpen={onOpen} h={168}>
          <WidgetHeader accent={accent} right={config.showFng !== false ? (
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 10, color: "rgba(255,255,255,0.55)" }}>Fear &amp; Greed</span>
              <FngMini fng={fng} size={28} />
            </div>) : null} />
          <div style={{ display: "flex", flexDirection: "column", gap: 9, flex: 1, justifyContent: "center" }}>
            {assets.slice(0, 3).map((a) => <WRow key={a.id} a={a} accent={accent} currency={currency} />)}
          </div>
        </WidgetShell>
      </div>
    );
  }

  // large
  return (
    <div style={{ width: 352 }}>
      <WidgetShell onOpen={onOpen} h={360}>
        <WidgetHeader accent={accent} right={
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, color: "rgba(255,255,255,0.5)" }}>Fear &amp; Greed</div>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: window.DATA.fngColor(fng.value), fontWeight: 700 }}>{window.DATA.fngLabel(fng.value)}</div>
            </div>
            <FngMini fng={fng} size={34} />
          </div>} />
        <div style={{ display: "flex", flexDirection: "column", gap: 0, flex: 1 }}>
          {assets.slice(0, 5).map((a, i) => (
            <div key={a.id} style={{ padding: "8.5px 0", borderTop: i ? "1px solid rgba(255,255,255,0.07)" : "none" }}>
              <WRow a={a} accent={accent} currency={currency} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8, paddingTop: 8, borderTop: "1px solid rgba(255,255,255,0.07)" }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 9.5, color: "rgba(255,255,255,0.4)" }}>Aktualizováno 9:30</span>
          <span style={{ fontFamily: "var(--font-ui)", fontSize: 10, color: accent, fontWeight: 600 }}>Otevřít aplikaci →</span>
        </div>
      </WidgetShell>
    </div>
  );
}

// ── Android home-screen launcher ─────────────────────────────────────
function AppIcon({ label, bg, glyph, onClick, accent }) {
  return (
    <div onClick={onClick} className="press" style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, cursor: onClick ? "pointer" : "default", width: 64 }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: bg, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 10px rgba(0,0,0,0.3)" }}>{glyph}</div>
      <span style={{ fontSize: 11, color: "#fff", fontFamily: "var(--font-ui)", textShadow: "0 1px 3px rgba(0,0,0,0.6)", whiteSpace: "nowrap" }}>{label}</span>
    </div>
  );
}

function HomeScreen({ accent, currency, fng, widgetConfig, onOpen, onOpenWidgetSettings }) {
  const cwGlyph = (
    <div style={{ width: 26, height: 26, borderRadius: 9, background: accent, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ display: "flex", gap: 2, alignItems: "flex-end" }}>
        <div style={{ width: 3, height: 8, background: "#fff", borderRadius: 1 }} />
        <div style={{ width: 3, height: 13, background: "#fff", borderRadius: 1 }} />
        <div style={{ width: 3, height: 6, background: "#fff", borderRadius: 1 }} />
      </div>
    </div>
  );
  const dummy = [
    { label: "Telefon", bg: "#1f6f43", g: "📞" },
    { label: "Zprávy", bg: "#2a5db0", g: "💬" },
    { label: "Fotky", bg: "#7a3ea8", g: "🖼️" },
    { label: "Mapy", bg: "#2e7d6b", g: "🗺️" },
  ];
  return (
    <div style={{
      minHeight: "100%",
      background: "radial-gradient(120% 80% at 70% 0%, #1a2742 0%, #0d1320 42%, #060810 100%)",
      display: "flex", flexDirection: "column", padding: "8px 18px 0",
    }}>
      {/* clock */}
      <div style={{ textAlign: "center", marginTop: 18, marginBottom: 20 }}>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 64, fontWeight: 300, color: "#fff", lineHeight: 1, letterSpacing: "-0.02em", textShadow: "0 2px 12px rgba(0,0,0,0.4)" }}>9:30</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "rgba(255,255,255,0.8)", marginTop: 4 }}>Pátek, 5. června · 23 °C</div>
      </div>

      {/* widgets */}
      <div style={{ display: "flex", flexDirection: "column", gap: 14, alignItems: "center" }}>
        <div onContextMenu={(e) => { e.preventDefault(); onOpenWidgetSettings(); }} style={{ width: 352 }}>
          <Widget size="large" config={widgetConfig} accent={accent} currency={currency} fng={fng} onOpen={onOpen} />
        </div>
        <div style={{ display: "flex", gap: 14, justifyContent: "center" }} onContextMenu={(e) => { e.preventDefault(); onOpenWidgetSettings(); }}>
          <Widget size="small" config={{ assets: ["BTC"] }} accent={accent} currency={currency} fng={fng} onOpen={onOpen} />
          <Widget size="small" config={{ assets: ["XAU"] }} accent={accent} currency={currency} fng={fng} onOpen={onOpen} />
        </div>
      </div>

      <div style={{ flex: 1, minHeight: 18 }} />

      {/* hint */}
      <div style={{ textAlign: "center", marginBottom: 10 }}>
        <span style={{ fontFamily: "var(--font-ui)", fontSize: 11, color: "rgba(255,255,255,0.45)" }}>Klepnutím na widget otevřeš aplikaci · podržením ji nastavíš</span>
      </div>

      {/* app row */}
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <AppIcon label="CryptoWidget" bg="#0f1318" glyph={cwGlyph} onClick={onOpen} accent={accent} />
        {dummy.map((d) => (
          <AppIcon key={d.label} label={d.label} bg={d.bg} glyph={<span style={{ fontSize: 24 }}>{d.g}</span>} />
        ))}
      </div>

      {/* dock */}
      <div style={{
        display: "flex", justifyContent: "space-around", alignItems: "center",
        background: "rgba(255,255,255,0.08)", backdropFilter: "blur(12px)",
        borderRadius: 28, padding: "12px 8px", margin: "10px 0 6px",
      }}>
        {[{ g: "📞", b: "#1f6f43" }, { g: "✉️", b: "#b03a3a" }, { g: "🌐", b: "#2a5db0" }, { g: "📷", b: "#444" }].map((d, i) => (
          <div key={i} style={{ width: 52, height: 52, borderRadius: 16, background: d.b, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{d.g}</div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Widget, WidgetShell, WRow, FngMini, HomeScreen });
