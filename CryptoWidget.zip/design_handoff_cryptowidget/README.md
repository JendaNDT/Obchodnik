# Handoff: CryptoWidget — Android aplikace

## Přehled

CryptoWidget je nativní Android aplikace pro sledování cen kryptoměn, drahých kovů, komodit a akciových indexů. Zobrazuje základní informace ve widgetu na ploše telefonu; po klepnutí se otevře plnohodnotná aplikace s watchlistem, grafy, Fear & Greed indexem, portfoliem a cenovými alerty.

Cílová platforma: **Android (nativní — Jetpack Compose)**.  
Jazyk UI: **čeština** (lokalizovatelné).  
Téma: výhradně **tmavý režim** (3 varianty, viz Témata).

---

## O souborech v tomto balíčku

Soubory v tomto balíčku jsou **HTML/React prototypy vytvořené jako design reference** — ukazují zamýšlený vzhled, rozložení a chování obrazovek. **Nejde o produkční kód.**

Úkolem vývojáře je **přepsat tyto obrazovky v nativním Androidu (Jetpack Compose)** s použitím odpovídajících komponent, témat a vzorů daného prostředí. Prototypy slouží jako přesná vizuální specifikace.

### Soubory v balíčku

| Soubor | Obsah |
|---|---|
| `CryptoWidget.html` | Hlavní interaktivní prototyp (otevři v prohlížeči) |
| `data.js` | Mockovaná data + generátor grafových sérií |
| `fmt.js` | Formátování čísel, cen, procent (cs-CZ) |
| `charts.jsx` | SVG komponenty: Sparkline, PriceChart, Gauge, HistoryArea |
| `ui.jsx` | Sdílené primitivy: AssetIcon, Change, Card, Icon, SectionLabel |
| `widgets.jsx` | Android home-screen widgety (small/medium/large) + launcher |
| `screens.jsx` | Trh, Detail aktiva, Fear & Greed |
| `screens2.jsx` | Vyhledávání, Portfolio, Alerty, Nastavení widgetu |
| `screens3.jsx` | Onboarding, Nastavení aplikace, prázdné stavy, notif banner |
| `app.jsx` | Hlavní router, bottom nav, splah, témata |

### Fidelita

**High-fidelity.** Prototypy jsou pixel-přesné mockupy s finálními barvami, typografií, rozestupy a interakcemi. Vývojář by měl UI přepsat s co nejvyšší věrností vizuálnímu designu.

---

## Aplikační flow

```
Splash screen (1,2 s)
  └─ Onboarding (4 kroky)
       ├─ 1. Uvítání + feature list
       ├─ 2. Výběr aktiv
       ├─ 3. Povolení oznámení
       └─ 4. Hotovo → Android plocha
            └─ Klepnutí na widget / ikonu → Aplikace
                 ├─ Trh (výchozí tab)
                 ├─ Portfolio
                 ├─ F&G Index
                 ├─ Alerty
                 └─ Nastavení
```

---

## Obrazovky

### 1. Splash screen
**Účel:** Branding + inicializace dat.  
**Trvání:** ~1,2 s, pak přechod do Onboardingu (nebo rovnou na plochu, pokud už onboarding proběhl).

| Prvek | Specifikace |
|---|---|
| Pozadí | `#07090c` (bg terminal) |
| Logo ikona | 82×82 dp, `border-radius: 26dp`, tmavý gradient + bar chart z 5 sloupců |
| Sloupce grafu | výšky: 9, 15, 7, 12, 11 dp; barvy viz Accent paleta |
| Název | "CryptoWidget", Hanken Grotesk 800, 22 sp, `#e7eaef` |
| Loading text | "Načítám data…", JetBrains Mono 11 sp, `#5c6573`, pozice dole na obrazovce |

---

### 2. Onboarding — Krok 1: Uvítání
**Účel:** Představení aplikace novému uživateli.

**Rozložení:** Column, vertically centered, padding 28dp all sides.

| Prvek | Specifikace |
|---|---|
| Logo | 88×88 dp, `border-radius: 28dp`, stejné jako splash |
| Nadpis | "CryptoWidget", Hanken Grotesk 800, 30 sp, `#e7eaef`, letter-spacing -0.02em |
| Podnadpis | "Krypto, kovy a komodity…", 15,5 sp, `#5c6573`, line-height 1.5 |
| Feature list | 3 řádky: ikona (34×34 dp, `border-radius: 10dp`, `accent+22` background) + text 14 sp `#99a2af` |
| Feature texty | "Widget na ploše s aktuálními cenami" / "Grafy a sledování vývoje aktiv" / "Okamžité alerty na cílové ceny" |
| CTA button | "Začít →", výška 56 dp, plná šířka, accent fill, Hanken Grotesk 700, 16 sp |
| Progress dots | 3 dots (aktivní: 20×5 dp, ostatní: 5×5 dp), accent barva aktivní |

---

### 3. Onboarding — Krok 2: Výběr aktiv
**Účel:** Personalizace watchlistu.

| Prvek | Specifikace |
|---|---|
| Nadpis | "Jaká aktiva tě zajímají?", 24 sp, 800 |
| Podnadpis | "Vyber alespoň jedno — kdykoli změníš.", 14 sp, `var(--text-3)` |
| Kategorie | Sekce Krypto / Kovy / Komodity & indexy, každá s chip buttony |
| Chip neaktivní | padding 8×13 dp, bg `var(--surface)`, border `var(--border)`, JetBrains Mono 600, 13 sp |
| Chip aktivní | bg `var(--accent)`, color `#fff`, check icon vlevo |
| CTA | "Pokračovat (N aktiv)" — počet se aktualizuje živě |

---

### 4. Onboarding — Krok 3: Oznámení
**Účel:** Žádost o povolení push notifikací.

| Prvek | Specifikace |
|---|---|
| Ikona zvonu | 78×78 dp, `border-radius: 24dp`, `accent+1f` bg |
| Nadpis | "Cenové alerty", 24 sp 800 |
| Mock notifikace | preview karta (bg `var(--surface)`, border-radius 16dp) s ikonou BTC, textem "BTC překročila $70 000" |
| Primární CTA | "Zapnout oznámení", accent fill |
| Sekundární CTA | "Teď ne", 14 sp, `var(--text-3)`, bez bg |

---

### 5. Onboarding — Krok 4: Hotovo
**Účel:** Potvrzení dokončení onboardingu.

| Prvek | Specifikace |
|---|---|
| Ikona | 82×82 dp kruh, `var(--up)+18` bg, check icon 38 dp, `var(--up)` |
| Nadpis | "Vše nastaveno!", 26 sp 800 |
| Podnadpis | "Tvůj watchlist je připraven. Přidej si widget na plochu." |
| CTA | "Přejít do aplikace →", accent fill, 56 dp výška |

---

### 6. Android plocha (Home Screen)
**Účel:** Ukázka widgetů na ploše.

#### Widget — Velký (4×4 buňky)
Rozměry: 352×360 dp. Backdrop blur pozadí.

| Prvek | Specifikace |
|---|---|
| Header | Logo (16×16 dp, accent bg) + "CryptoWidget" label + F&G mini gauge vpravo |
| Asset řádky | 5 řádků, každý: ikona 24dp + ticker (Mono 600, 12,5sp) + sparkline 48×18 dp + cena + % změna |
| Footer | "Aktualizováno 9:30" vlevo, "Otevřít aplikaci →" vpravo (accent barva) |
| Pozadí | `linear-gradient(155deg, rgba(20,24,31,0.82), rgba(10,12,16,0.88))`, blur 8dp |
| Border | `rgba(255,255,255,0.10)`, border-radius 24dp |

#### Widget — Střední (4×2 buňky)
Rozměry: 352×168 dp. 3 asset řádky + F&G mini gauge.

#### Widget — Malý (2×2 buňky)
Rozměry: 168×168 dp. 1 aktivum: ticker + název + velká cena + % změna + sparkline.

---

### 7. Trh (Watchlist)
**Účel:** Přehled sledovaných aktiv, vstupní bod do aplikace.

**Rozložení:** Sticky top bar → F&G card → category tabs → asset list.

#### TopBar
Výška 56 dp, sticky. Nadpis "Trh" Hanken 700, 22 sp. Vpravo: ikona lupy + ikona zvonu (s badge tečkou při aktivním alertu).

#### Fear & Greed karta
Padding 14 dp, border-radius `var(--radius)`. Flex row:
- Mini gauge (48×48 dp, SVG kruh s progress arc)
- Label "Index strachu a chamtivosti" (Mono 11sp uppercase) + hodnota+popis (17 sp, barva dle hodnoty)
- Chevron ikona vpravo
- Barva hodnotného textu: < 25 → `#ef4444`, 25-44 → `#f59e0b`, 45-54 → `#eab308`, 55-74 → `#84cc16`, 75+ → `#22c55e`

#### Category tabs
Horizontálně scrollovatelné, padding 12×16 dp. Chip výška 34 dp.
Kategorie: Vše / Krypto / Kovy / Komodity / Indexy.

#### Asset řádek (normální hustota)
Výška ~64 dp, padding 12,5×16 dp. Layout:

```
[Ikona 38dp] [Ticker+Název 92dp] [Sparkline 64×28dp flex] [Cena+%change 92dp right]
```

- **Ikona:** kruh `border-radius: 38dp`, `asset.color+"22"` bg, `asset.color+"55"` border, monogram v `asset.color`, JetBrains Mono 600
- **Ticker:** Mono 600, 14,5 sp, `var(--text)`; Název: UI 12 sp, `var(--text-3)`, ellipsis
- **Sparkline:** SVG line chart, barva `var(--up)` nebo `var(--down)`
- **Cena:** Mono 600, 14 sp; **Změna:** Mono 600, 12 sp, `var(--up/down)` + šipka

#### CTA přidat
Dashed border, border-radius `var(--radius)`, padding 14 dp, "+ Přidat aktivum do watchlistu".

#### Prázdný stav watchlistu
Centrovaná ikona hvězdy (64×64 dp, radius 20dp, `var(--surface)`) + nadpis + CTA "Hledat aktiva".

---

### 8. Detail aktiva
**Účel:** Podrobné informace o jednom aktivu s grafem.

**Rozložení:** Sticky TopBar → Cena+změna → Toggle grafu → Graf → Range tabs → Stats grid → Action buttons.

#### Header sekce
Ikona 44 dp + velká cena (Mono 700, 30 sp, letter-spacing -0.02em) + chip se % změnou.

#### Toggle Křivka / Svíčky
Segmented control vpravo nahoře: 2 optiony, padding 5×12 dp, aktivní: `var(--accent)`.

#### Graf
SVG, šířka 388 dp, výška 208 dp. Gridlines: 5 horizontálních čar, opacity 7 %, label 9,5 sp Mono.

**Line mode:** area fill s gradientem (accent → transparent), 2dp stroke, dot na poslední hodnotě.  
**Candle mode:** OHLC svíčky, zelená `#16c784` / červená `#ea3943`, wick 1dp.

#### Range tabs
Pět tlačítek (1D / 1T / 1M / 1R / VŠE), flex distribute, aktivní: `var(--surface-2)` + border.

#### Stats grid
2 sloupce, gap 8 dp. Každá tile: padding 11×13 dp, bg `var(--surface)`, border-radius `var(--radius-sm)`.
Label: UI 11,5 sp `var(--text-3)`; Hodnota: Mono 600, 15 sp `var(--text)`.
Statistiky: 24h max, 24h min, Změna 7d, Změna 30d, Tržní kap. / Kategorie, Objem 24h.

#### Action buttons
Flex row, gap 10, padding 16 dp. "Alert" — border button; "Sledovat / Ve watchlistu" — accent fill button.

---

### 9. Fear & Greed index
**Účel:** Detail kompozitního indexu nálady trhu.

#### Gauge (semafor)
SVG polokruh, průměr 240 dp. 5 barevných segmentů (width stroke 14 dp):
- 0–25: `#ef4444` | 25–45: `#f59e0b` | 45–55: `#eab308` | 55–75: `#84cc16` | 75–100: `#22c55e`
- Ručička: 3dp stroke, pivot kruh 6dp
- Hodnota: Mono 700, 62 sp, barva dle pásma; Label: UI 13 sp, `var(--text-3)`

#### Historické hodnoty (row of 4)
Flex row: včera / min. týden / min. měsíc / loni. Každá tile: Mono 700, 22 sp (barva dle hodnoty) + label 10,5 sp.

#### Historický graf
SVG area chart, výška 92 dp, zelená `#84cc16`.

#### Složení indexu
6 řádků v kartě. Každý: label + váha + numerická hodnota + progress bar (6 dp výška, barva dle hodnoty).

---

### 10. Vyhledávání
**Účel:** Nalezení aktiv a přidání do watchlistu.

**Rozložení:** Sticky search bar → sekce dle kategorie → asset řádky se star ikonou.

#### Search bar
Flex row: back šipka + input s lupou ikonou, bg `var(--surface)`, border-radius `var(--chip-radius)`, výška 44 dp. Clear (×) ikona při neprázdném dotazu.

#### Asset řádky
Jako na watchlistu, navíc star ikona (outline/fill) vpravo. Klepnutím na star → toggle sledování.

---

### 11. Portfolio
**Účel:** Sledování hodnoty a P/L pozic.

#### Summary karta
- Nadpis "Celková hodnota", Mono 700, 34 sp, letter-spacing -0.02em
- Dnes +/−: Mono 600, 13 sp, `var(--up/down)`
- Celkem P/L: stejně
- Allocation bar: 8 dp výška, border-radius 4dp, segmenty v barvách aktiv proportional
- Legend: tečky 8dp + ticker + %

#### Pozice řádky
Ikona 38dp + ticker + množství (Mono 11,5 sp text-3) + hodnota + % P/L.

#### Prázdný stav
Ikona peněženky (64 dp, radius 20dp) + "Žádné pozice" + CTA "Přidat první pozici".

#### Sheet: Přidat pozici
Bottom sheet, slide-up animace. Výběr aktiva (chip row), množství + nákupní cena (2 sloupce), live preview hodnoty a P/L. CTA "Uložit pozici" (disabled styl, dokud nejsou vyplněna obě pole).

---

### 12. Alerty
**Účel:** Správa cenových upozornění.

#### Alert řádek
Ikona aktiva 38dp + podmínka (tick, cena Mono 600) + status text + trash ikona + Switch toggle.
Status: "Aktivní · čeká na splnění" (`var(--text-3)`) nebo "✓ Spuštěno · 9:12" (`var(--up)`).

#### Sheet: Nový alert
Bottom sheet. Výběr aktiva (popular chips), podmínka (nad / pod — 2 tlačítka), cílová cena (number input, Mono 600, 18sp). Hint "Aktuálně: $X" pod inputem.

#### Prázdný stav
Ikona zvonu + "Zatím žádné alerty".

---

### 13. Nastavení widgetu
**Účel:** Konfigurace widgetu na ploše.

**Rozložení:** Živý náhled widgetu na tmavém tapetu nahoře → sekce konfigurace dole.

#### Živý náhled
Tmavý gradient bg `radial-gradient(120% 90% at 60% 0%, #1a2742, #0a0e16)`. Widget se renderuje s aktuálními nastaveními.

#### Velikost
3 tlačítka: Malý 2×2 / Střední 4×2 / Velký 4×4.

#### Aktiva
Chip grid z watchlistu. Vybraná aktiva: accent fill. Max count dle velikosti (1/3/5).

#### Přepínače
"Zobrazit Fear & Greed" + "Automatická aktualizace" — iOS-style Switch (46×27 dp).

---

### 14. Nastavení aplikace
**Účel:** Globální nastavení, preference, info o aplikaci.

**Sekce:** Profil → Zobrazení → Měna & jednotky → Oznámení → Zdroj dat → Aplikace.

#### Profil karta
Avatar monogram "CW" (52dp kruh, `accent+55` border) + "Můj účet" + podtext. Chevron vpravo.

#### Settings řádek
Flex: label (UI 15 sp) + subtext (UI 12 sp, text-3) + right element (Switch nebo Chevron). Oddělovač `border-top: var(--border)`.

#### Bottom sheety
Výběr tématu (3 optiony s checkmarkem) a výběr měny (USD/CZK s symbolem).

---

### 15. Push notification banner
**Účel:** In-app overlay při spuštění alertu.

**Pozice:** Absolute, top 44 dp, margin 12 dp vlevo i vpravo. Z-index 50.  
**Animace:** slideDown 280ms `cubic-bezier(.2,.8,.2,.1)`.  
**Pozadí:** `rgba(20,22,30,0.96)`, border `var(--border-strong)`, border-radius 16dp.  
**Obsah:** ikona aktiva 36dp + "CryptoWidget · Alert" (UI 700, 13,5 sp) + popis podmínky + "Otevřít" button (accent) + × dismiss.  
**Auto-dismiss:** 5 s.

---

### 16. Chybové a prázdné stavy

#### Chybový stav (síť)
Centrovaný. Ikona `!` (64dp, radius 20dp, `var(--down)` stroke) + "Nepodařilo se načíst data" (700, 17 sp) + popis + "Zkusit znovu" CTA + chybový kód Mono 11sp.

#### Skeleton loader
Pulzující placeholder řádky pro watchlist. Animace: `opacity 0.55 ↔ 1.0`, 1,4 s ease-in-out infinite.

---

## Interakce & animace

| Akce | Specifikace |
|---|---|
| Klepnutí (press) | `scale(0.975)`, `opacity: 0.88`, 80ms ease |
| Bottom sheet slide-up | `translateY(100% → 0)`, 260ms `cubic-bezier(.2,.8,.2,1)` |
| Notif banner slide-down | `translateY(-12px → 0) + opacity 0→1`, 280ms |
| Screen fade-up | `opacity 0→1 + translateY(6px→0)`, 300ms ease |
| Skeleton puls | `opacity 0.55↔1.0`, 1400ms ease-in-out infinite |
| Chip/tab toggle | background + color transition 150ms |
| Graph range switch | okamžité překreslení SVG |

**Gesto pill (domů):** tap na 120×4,5 dp pill v dolní části obrazovky → návrat na Android plochu.

---

## Design tokens

### Témata

#### Terminal (výchozí)
```
--bg:           #07090c
--surface:      #0e1218
--surface-2:    #171c24
--border:       rgba(255,255,255, 0.07)
--border-strong:rgba(255,255,255, 0.15)
--text:         #e7eaef
--text-2:       #99a2af
--text-3:       #5c6573
--radius:       14dp
--radius-sm:    10dp
--chip-radius:  9dp
```

#### Aurora
```
--bg:           #090a14
--surface:      #15172a
--surface-2:    #1f2340
--border:       rgba(150,165,255, 0.10)
--border-strong:rgba(150,165,255, 0.22)
--text:         #edeef7
--text-2:       #a6acca
--text-3:       #6c7193
--radius:       20dp
--radius-sm:    15dp
--chip-radius:  999dp  (plně zaoblené pill)
```

#### Mono
```
--bg:           #0a0a0a
--surface:      #121212
--surface-2:    #1d1d1d
--border:       rgba(255,255,255, 0.08)
--border-strong:rgba(255,255,255, 0.18)
--text:         #ededed
--text-2:       #8c8c8c
--text-3:       #565656
--radius:       4dp
--radius-sm:    4dp
--chip-radius:  4dp
```
V Mono tématu se UI font také přepne na JetBrains Mono (monospace everywhere).

### Sémantické barvy (sdílené napříč tématy)
```
--up:           #16c784   (kladná % změna, zisky)
--down:         #ea3943   (záporná % změna, ztráty)
```

### Akcentní paleta (uživatel vybírá)
```
Modrá (výchozí):  #3b82f6
Zelená:           #16c784
Oranžová (BTC):   #f7931a
Fialová:          #a78bfa
```
Tinta na akcentní barvě (text na accent bg): vždy `#ffffff`.

### Barvy aktiv
| Ticker | Barva |
|---|---|
| BTC | `#f7931a` |
| ETH | `#627eea` |
| SOL | `#14f195` |
| BNB | `#f3ba2f` |
| XRP | `#23292f` |
| ADA | `#0033ad` |
| DOGE | `#c2a633` |
| AVAX | `#e84142` |
| XAU | `#d4af37` |
| XAG | `#c0c0c0` |
| XPT | `#a8b3c4` |
| XPD | `#9aa0a6` |
| BRENT | `#5b8c3e` |
| WTI | `#6b9c4e` |
| NG | `#4aa3df` |
| WHEAT | `#d6b85a` |
| COPPER | `#c87f4a` |
| SPX | `#3b82f6` |
| NDX | `#8b5cf6` |
| DJI | `#22c55e` |
| DAX | `#ef4444` |

Ikona aktiva: kruh s `asset.color+"22"` výplní a `asset.color+"55"` border. Monogram z tickeru v `asset.color`.

---

## Typografie

| Role | Font | Váha | Použití |
|---|---|---|---|
| Nadpisy, UI text | Hanken Grotesk | 400/500/600/700/800 | Názvy obrazovek, labely, body text |
| Čísla, kódy | JetBrains Mono | 400/500/600/700 | Ceny, %, tickers, kódy |

Zdrojový Google Fonts URL:
```
https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700
```

Android: přidat oba fonty jako downloadable fonts nebo bundled assets.

---

## Spacing škála

| Token | Hodnota | Použití |
|---|---|---|
| xs | 4 dp | Mezery uvnitř chip, badge offset |
| sm | 8 dp | Gap v řádcích, margin mezi elementy |
| md | 12–14 dp | Padding karet, mezeera v listech |
| lg | 16 dp | Globální horizontální padding stránek |
| xl | 20–24 dp | Spacing mezi sekcemi |
| 2xl | 28–32 dp | Padding onboarding obrazovek |

---

## Navigace

### Bottom Navigation Bar
5 tabů: Trh (chart) · Portfolio (wallet) · Index (gauge) · Alerty (bell+badge) · Nastavení (settings).

Aktivní stav: accent barva ikony + akcentní pill 32×28 dp bg.  
Neaktivní: `var(--text-3)`.  
Label: UI 10,5 sp, weight 700 aktivní / 500 neaktivní.  
Výška baru: ~64 dp (8dp top padding, 4dp bottom).

### Push navigace
Detail aktiva se pushuje jako nová obrazovka (back šipka v TopBaru).  
Vyhledávání se pushuje z Markets.

### Bottom sheety
Alert tvorba, přidání pozice, nastavení tématu/měny — bottom sheet s handle barem (38×4 dp, `var(--border-strong)`, radius 4dp).  
Scroll uvnitř sheetu pro delší obsah.

---

## State management

### Klíčové state proměnné

| Proměnná | Typ | Popis |
|---|---|---|
| `phase` | `"splash" \| "onboarding" \| "home" \| "app"` | Fáze životního cyklu |
| `tab` | `"markets" \| "portfolio" \| "fng" \| "alerts" \| "settings"` | Aktivní bottom nav tab |
| `pushed` | `null \| {type, ...}` | Push-navigovaná obrazovka |
| `watchlist` | `string[]` | ID sledovaných aktiv |
| `holdings` | `{id, qty, avg}[]` | Portfoliové pozice |
| `alerts` | `Alert[]` | Cenové alerty |
| `widgetConfig` | `{assets: string[], showFng: boolean}` | Konfigurace widgetu |
| `theme` | `"terminal" \| "aurora" \| "mono"` | Aktivní téma |
| `accent` | `string` | Hex akcentní barvy |
| `currency` | `"USD" \| "CZK"` | Zobrazovací měna |

### Persistence
- `theme`, `accent`, `currency`, `density`, `defaultChart` → SharedPreferences / DataStore
- `watchlist`, `holdings`, `alerts`, `widgetConfig` → Room database nebo DataStore

---

## Widget (Android App Widget)

### Velikosti
| Název | Buňky | Min. dp |
|---|---|---|
| Malý | 2×2 | 110×110 dp |
| Střední | 4×2 | 250×110 dp |
| Velký | 4×4 | 250×250 dp |

### Aktualizace
Doporučená frekvence: každých 5 minut (`AppWidgetManager.updateAppWidget`).

### Tapnutí na widget
`PendingIntent` → otevře hlavní Activity s `ACTION_MAIN`.

### Kontext menu (long press)
→ Nastavení widgetu (dedicated Activity nebo bottom sheet v hlavní appce).

---

## API a data

Prototyp používá deterministicky generovaná mock data. Doporučené reálné API:

| Data | Zdroj | Endpoint (příklad) |
|---|---|---|
| Kryptoměny | CoinGecko | `GET /api/v3/coins/markets` |
| Drahé kovy | Metals-API / GoldAPI | `GET /latest?base=USD&currencies=XAU,XAG` |
| Komodity | Alpha Vantage | `GET /query?function=COMMODITY_PRICE` |
| Akciové indexy | Yahoo Finance / Polygon.io | index tickers |
| Fear & Greed | alternative.me | `GET https://api.alternative.me/fng/` |

Formátování: ceny zobrazovat na 2–5 desetinných míst dle hodnoty (< $1 → 5 des., $1–100 → 2, > $100 → 0–2).

---

## Ikonografie

Prototyp používá vlastní SVG ikony (24×24 grid, stroke 1.8–2dp, linecap/linejoin round). V produkci doporučujeme:
- **Material Symbols** (rounded variant) pro konzistenci s Android HIG
- Nebo vlastní sadu dle výše popsaného stroke stylu

Použité ikony: search, bell, chart (line), wallet, gauge, settings, plus, back/chevron, star (outline+fill), check, close, trash, bolt, filter, grid, arrowUpRight, dots (vertical).

---

## Poznámky pro vývojáře

1. **Monospace čísla:** Všechny ceny a procenta zobrazuj v JetBrains Mono nebo systémovém monospace — zabraňuje poskakování čísel při aktualizaci.
2. **Ikony aktiv:** V prototypu jsou monogramy. Pro produkci doporučujeme SVG loga z [cryptoicons.co](https://cryptoicons.co) nebo podobného zdroje.
3. **Sparkline grafy:** Mohou být renderovány jako Android Canvas nebo MPAndroidChart. Klíčové: area fill s gradientem, `strokeWidth 1,6dp`.
4. **Gauge (F&G):** Implementovat jako Canvas.drawArc() s 5 segmenty, ručička jako Canvas.drawLine() rotovaná dle hodnoty.
5. **Widget blur pozadí:** Android 12+ podporuje `@xml/appwidget_provider` s `android:roundedCorners` a Blur efekt přes `AppWidgetManager`. Na starších verzích použít poloprůhledné pozadí.
6. **Animace skel:** Shimmer efekt — ObjectAnimator na `translationX` přes LinearGradient maskovaný na CompositeShader.
7. **CZK konverze:** Pevný kurs v prototypu: 1 USD = 23,4 CZK. V produkci fetchovat z ECB nebo jiného kurzovního API.
