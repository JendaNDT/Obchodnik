/* fmt.js — number / price formatting helpers (cs-CZ) */
(function () {
  const CZK_RATE = 23.4;

  function decimalsFor(v) {
    const a = Math.abs(v);
    if (a >= 1000) return 0;
    if (a >= 100) return 2;
    if (a >= 1) return 2;
    if (a >= 0.1) return 4;
    return 5;
  }

  function num(v, dec) {
    if (dec == null) dec = decimalsFor(v);
    return new Intl.NumberFormat("cs-CZ", {
      minimumFractionDigits: dec, maximumFractionDigits: dec,
    }).format(v);
  }

  // currency: "USD" | "CZK"
  function price(v, currency, dec) {
    if (currency === "CZK") {
      const c = v * CZK_RATE;
      const d = dec != null ? dec : (Math.abs(c) >= 1000 ? 0 : 2);
      return num(c, d) + " Kč";
    }
    return "$" + num(v, dec);
  }

  function compact(v, currency) {
    let val = v;
    let suffix = "";
    if (currency === "CZK") val = v * CZK_RATE;
    const sym = currency === "CZK" ? " Kč" : "$";
    const a = Math.abs(val);
    if (a >= 1e12) { val /= 1e12; suffix = " bil."; }
    else if (a >= 1e9) { val /= 1e9; suffix = " mld."; }
    else if (a >= 1e6) { val /= 1e6; suffix = " mil."; }
    else if (a >= 1e3) { val /= 1e3; suffix = " tis."; }
    const body = new Intl.NumberFormat("cs-CZ", { maximumFractionDigits: 2 }).format(val);
    return (currency === "CZK" ? body + suffix + " Kč" : sym + body + suffix);
  }

  function pct(v) {
    const s = v >= 0 ? "+" : "−";
    return s + new Intl.NumberFormat("cs-CZ", {
      minimumFractionDigits: 2, maximumFractionDigits: 2,
    }).format(Math.abs(v)) + " %";
  }

  function signedPrice(v, currency) {
    const s = v >= 0 ? "+" : "−";
    return s + price(Math.abs(v), currency);
  }

  window.FMT = { price, compact, pct, num, signedPrice, decimalsFor, CZK_RATE };
})();
