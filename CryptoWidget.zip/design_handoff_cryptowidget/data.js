/* data.js — mock market data + deterministic chart series for CryptoWidget */
(function () {
  // ── deterministic PRNG (mulberry32) ───────────────────────────────
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Generate a realistic-ish random walk -> closes + OHLC candles.
  function genSeries(seed, n, base, vol) {
    const rnd = mulberry32(seed);
    const closes = [];
    const candles = [];
    let price = base;
    // gentle drift so the series ends near the "current" price
    let drift = (rnd() - 0.45) * vol * 0.15;
    for (let i = 0; i < n; i++) {
      const o = price;
      const step = (rnd() - 0.5) * vol + drift;
      let c = o * (1 + step);
      const hi = Math.max(o, c) * (1 + rnd() * vol * 0.5);
      const lo = Math.min(o, c) * (1 - rnd() * vol * 0.5);
      candles.push({ o, h: hi, l: lo, c });
      closes.push(c);
      price = c;
      if (i % 12 === 0) drift = (rnd() - 0.45) * vol * 0.15;
    }
    let min = Infinity, max = -Infinity;
    candles.forEach((k) => { if (k.l < min) min = k.l; if (k.h > max) max = k.h; });
    return { closes, candles, min, max };
  }

  // Build per-asset multi-range series cache
  function buildSeries(seed, base, trendUp) {
    const v = trendUp ? 0.022 : 0.02;
    return {
      "1D": genSeries(seed + 1, 48, base * 0.992, v * 0.5),
      "1T": genSeries(seed + 2, 56, base * 0.97, v),
      "1M": genSeries(seed + 3, 60, base * 0.9, v * 1.4),
      "1R": genSeries(seed + 4, 64, base * 0.62, v * 2.2),
      "VŠE": genSeries(seed + 5, 72, base * 0.35, v * 3),
    };
  }

  const RAW = [
    // krypto
    ["BTC", "Bitcoin", "krypto", 67432.10, 2.34, -3.1, 18.4, "#f7931a", 1331e9],
    ["ETH", "Ethereum", "krypto", 3521.88, 1.12, 4.2, 9.6, "#627eea", 423e9],
    ["SOL", "Solana", "krypto", 168.42, 5.67, 12.4, 41.2, "#14f195", 78e9],
    ["BNB", "BNB", "krypto", 604.21, -0.45, 1.8, 6.1, "#f3ba2f", 89e9],
    ["XRP", "XRP", "krypto", 0.6234, 3.21, -2.4, -8.3, "#23292f", 34e9],
    ["ADA", "Cardano", "krypto", 0.4521, -1.23, -5.6, -12.1, "#0033ad", 16e9],
    ["DOGE", "Dogecoin", "krypto", 0.1623, 8.91, 22.1, 33.4, "#c2a633", 23e9],
    ["AVAX", "Avalanche", "krypto", 38.12, 2.10, -1.2, 14.8, "#e84142", 14e9],
    // drahé kovy
    ["XAU", "Zlato", "kovy", 2389.50, 0.42, 1.1, 3.8, "#d4af37", null],
    ["XAG", "Stříbro", "kovy", 31.24, 1.05, 2.9, 11.2, "#c0c0c0", null],
    ["XPT", "Platina", "kovy", 1012.30, -0.62, -1.8, 2.1, "#a8b3c4", null],
    ["XPD", "Palladium", "kovy", 978.40, 0.88, 3.4, -9.6, "#9aa0a6", null],
    // komodity
    ["BRENT", "Ropa Brent", "komodity", 82.34, -1.12, -2.6, 1.4, "#5b8c3e", null],
    ["WTI", "Ropa WTI", "komodity", 78.91, -0.94, -2.1, 0.9, "#6b9c4e", null],
    ["NG", "Zemní plyn", "komodity", 2.84, 3.40, 8.2, -14.3, "#4aa3df", null],
    ["WHEAT", "Pšenice", "komodity", 6.12, 0.70, -1.4, 4.6, "#d6b85a", null],
    ["COPPER", "Měď", "komodity", 4.62, 1.90, 5.1, 12.7, "#c87f4a", null],
    // indexy
    ["SPX", "S&P 500", "indexy", 5431.60, 0.31, 1.2, 14.1, "#3b82f6", null],
    ["NDX", "NASDAQ 100", "indexy", 19210.40, 0.55, 1.9, 19.8, "#8b5cf6", null],
    ["DJI", "Dow Jones", "indexy", 38904.00, -0.12, 0.4, 7.2, "#22c55e", null],
    ["DAX", "DAX", "indexy", 18512.00, 0.22, 0.8, 9.4, "#ef4444", null],
  ];

  const UNIT = {
    XAU: "/oz", XAG: "/oz", XPT: "/oz", XPD: "/oz",
    BRENT: "/bbl", WTI: "/bbl", NG: "/MMBtu", WHEAT: "/bu", COPPER: "/lb",
  };

  const ASSETS = RAW.map((r, i) => ({
    id: r[0], ticker: r[0], name: r[1], category: r[2],
    price: r[3], change24h: r[4], change7d: r[5], change30d: r[6],
    color: r[7], marketCap: r[8], unit: UNIT[r[0]] || "",
    series: buildSeries(1000 + i * 37, r[3], r[4] >= 0),
  }));

  const byId = {};
  ASSETS.forEach((a) => { byId[a.id] = a; });

  const CATEGORIES = [
    { id: "vse", label: "Vše" },
    { id: "krypto", label: "Krypto" },
    { id: "kovy", label: "Kovy" },
    { id: "komodity", label: "Komodity" },
    { id: "indexy", label: "Indexy" },
  ];

  // Default watchlist (ids)
  const WATCHLIST = ["BTC", "ETH", "SOL", "XAU", "XAG", "BRENT", "SPX", "DOGE"];

  // Fear & Greed
  const FNG = {
    value: 72,
    yesterday: 68,
    lastWeek: 55,
    lastMonth: 41,
    lastYear: 74,
    history: [41, 38, 44, 49, 47, 52, 55, 51, 58, 61, 57, 63, 66, 64, 69, 68, 72],
    components: [
      { label: "Volatilita", score: 78, weight: "25 %" },
      { label: "Momentum trhu", score: 81, weight: "25 %" },
      { label: "Sociální sítě", score: 69, weight: "15 %" },
      { label: "Dominance BTC", score: 58, weight: "10 %" },
      { label: "Google trendy", score: 74, weight: "10 %" },
      { label: "Průzkumy", score: 63, weight: "15 %" },
    ],
  };

  function fngLabel(v) {
    if (v < 25) return "Extrémní strach";
    if (v < 45) return "Strach";
    if (v < 55) return "Neutrální";
    if (v < 75) return "Chamtivost";
    return "Extrémní chamtivost";
  }
  // hue along red->amber->green
  function fngColor(v) {
    if (v < 25) return "#ef4444";
    if (v < 45) return "#f59e0b";
    if (v < 55) return "#eab308";
    if (v < 75) return "#84cc16";
    return "#22c55e";
  }

  // Portfolio holdings: {id, qty, avg(buy price USD)}
  const HOLDINGS = [
    { id: "BTC", qty: 0.85, avg: 51200 },
    { id: "ETH", qty: 4.2, avg: 2980 },
    { id: "SOL", qty: 35, avg: 96.4 },
    { id: "XAG", qty: 120, avg: 27.8 },
    { id: "DOGE", qty: 5200, avg: 0.121 },
  ];

  // Alerts: {id, asset, op, target, active, triggered}
  const ALERTS = [
    { id: 1, asset: "BTC", op: ">", target: 70000, active: true, triggered: false },
    { id: 2, asset: "ETH", op: "<", target: 3200, active: true, triggered: false },
    { id: 3, asset: "XAU", op: ">", target: 2400, active: true, triggered: false },
    { id: 4, asset: "SOL", op: "<", target: 150, active: false, triggered: true },
    { id: 5, asset: "DOGE", op: ">", target: 0.20, active: true, triggered: false },
  ];

  window.DATA = {
    ASSETS, byId, CATEGORIES, WATCHLIST, FNG, HOLDINGS, ALERTS,
    fngLabel, fngColor, genSeries,
  };
})();
