/* screens.jsx — Markets, AssetDetail, FearGreed */

function TopBar({ title, sub, onBack, right, big }) {
  return (
    <div style={{ position: "sticky", top: 0, zIndex: 5, background: "var(--bg)", borderBottom: "1px solid var(--border)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", minHeight: 56, boxSizing: "border-box" }}>
        {onBack && (
          <div className="press" onClick={onBack} style={{ cursor: "pointer", margin: "-8px 0 -8px -8px", padding: 8 }}>
            <Icon name="back" size={24} color="var(--text)" />
          </div>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: big ? 22 : 18, color: "var(--text)", letterSpacing: "-0.01em", lineHeight: 1.1 }}>{title}</div>
          {sub && <div style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--text-3)", marginTop: 2 }}>{sub}</div>}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>{right}</div>
      </div>
    </div>
  );
}

function IconBtn({ name, onClick, color = "var(--text-2)", badge }) {
  return (
    <div className="press" onClick={onClick} style={{ position: "relative", cursor: "pointer", padding: 8, borderRadius: 10 }}>
      <Icon name={name} size={22} color={color} />
      {badge && <span style={{ position: "absolute", top: 5, right: 5, width: 7, height: 7, borderRadius: 7, background: "var(--accent)", border: "1.5px solid var(--bg)" }} />}
    </div>
  );
}

function AssetRow({ a, currency, onClick, density }) {
  const up = a.change24h >= 0;
  const py = density === "kompaktní" ? 9 : density === "vzdušná" ? 16 : 12.5;
  return (
    <div className="press row-sep" onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 12, padding: `${py}px 16px`, cursor: "pointer",
    }}>
      <AssetIcon asset={a} size={38} />
      <div style={{ width: 92, minWidth: 0 }}>
        <div style={{ fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 14.5, color: "var(--text)" }}>{a.ticker}</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.name}</div>
      </div>
      <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
        <Sparkline closes={a.series["1D"].closes} color={up ? "var(--up)" : "var(--down)"} width={64} height={28} />
      </div>
      <div style={{ textAlign: "right", minWidth: 92 }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 600, color: "var(--text)" }}>{window.FMT.price(a.price, currency)}<span style={{ color: "var(--text-3)", fontSize: 10 }}>{a.unit}</span></div>
        <div style={{ marginTop: 2, display: "flex", justifyContent: "flex-end" }}><Change value={a.change24h} size={12} /></div>
      </div>
    </div>
  );
}

function Tabs({ items, value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 8, overflowX: "auto", padding: "12px 16px", scrollbarWidth: "none" }} className="noscroll">
      {items.map((it) => {
        const active = it.id === value;
        return (
          <div key={it.id} className="press" onClick={() => onChange(it.id)} style={{
            padding: "7px 14px", borderRadius: "var(--chip-radius)", cursor: "pointer", whiteSpace: "nowrap",
            fontFamily: "var(--font-ui)", fontSize: 13.5, fontWeight: 600,
            background: active ? "var(--accent)" : "var(--surface)",
            color: active ? "var(--accent-ink)" : "var(--text-2)",
            border: `1px solid ${active ? "var(--accent)" : "var(--border)"}`,
          }}>{it.label}</div>
        );
      })}
    </div>
  );
}

// ── Markets / watchlist ──────────────────────────────────────────────
function Markets({ watchlist, currency, density, onOpenAsset, onSearch, onAlerts, onFng, fng }) {
  const [cat, setCat] = React.useState("vse");
  const list = watchlist
    .map((id) => window.DATA.byId[id])
    .filter((a) => a && (cat === "vse" || a.category === cat));
  const fngCol = window.DATA.fngColor(fng.value);
  return (
    <div>
      <TopBar title="Trh" big right={<>
        <IconBtn name="search" onClick={onSearch} />
        <IconBtn name="bell" onClick={onAlerts} badge />
      </>} />

      {/* Fear & Greed strip */}
      <div style={{ padding: "14px 16px 4px" }}>
        <Card pad={0} onClick={onFng} style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 14, padding: 14 }}>
          <FngMini fng={fng} size={48} />
          <div style={{ flex: 1 }}>
            <SectionLabel>Index strachu a chamtivosti</SectionLabel>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 17, fontWeight: 700, color: fngCol, marginTop: 3 }}>{window.DATA.fngLabel(fng.value)}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>včera {fng.yesterday}</div>
            <Icon name="chevron" size={18} color="var(--text-3)" />
          </div>
        </Card>
      </div>

      <Tabs items={window.DATA.CATEGORIES} value={cat} onChange={setCat} />

      <div style={{ paddingBottom: 8 }}>
        {list.length === 0 && cat === "vse"
          ? <EmptyWatchlist onSearch={onSearch} />
          : list.length === 0
          ? <div style={{ padding: 40, textAlign: "center", color: "var(--text-3)", fontFamily: "var(--font-ui)" }}>Žádná aktiva v této kategorii</div>
          : list.map((a) => <AssetRow key={a.id} a={a} currency={currency} density={density} onClick={() => onOpenAsset(a.id)} />)}
      </div>

      <div className="press" onClick={onSearch} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, margin: "4px 16px 20px", padding: 14, border: "1px dashed var(--border-strong)", borderRadius: "var(--radius)", color: "var(--text-2)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 600, fontSize: 14 }}>
        <Icon name="plus" size={18} color="var(--text-2)" /> Přidat aktivum do watchlistu
      </div>
    </div>
  );
}

// ── Asset detail ─────────────────────────────────────────────────────
const RANGES = ["1D", "1T", "1M", "1R", "VŠE"];
const RANGE_PCT = { "1D": "change24h", "1T": "change7d", "1M": "change30d", "1R": "change30d", "VŠE": "change30d" };

function StatTile({ label, value, sub }) {
  return (
    <div style={{ padding: "11px 13px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)" }}>
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 11.5, color: "var(--text-3)" }}>{label}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 15, fontWeight: 600, color: "var(--text)", marginTop: 3 }}>{value}</div>
      {sub && <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, marginTop: 1 }}>{sub}</div>}
    </div>
  );
}

function AssetDetail({ id, currency, inWatchlist, defaultChart, onBack, onToggleWatch, onAlert }) {
  const a = window.DATA.byId[id];
  const [range, setRange] = React.useState("1T");
  const [mode, setMode] = React.useState(defaultChart || "line");
  if (!a) return null;
  const series = a.series[range];
  const up = a[RANGE_PCT[range]] >= 0;
  const accentLine = up ? "var(--up)" : "var(--down)";
  const dayHi = Math.max(...a.series["1D"].candles.map((k) => k.h));
  const dayLo = Math.min(...a.series["1D"].candles.map((k) => k.l));
  return (
    <div>
      <TopBar title={a.ticker} sub={a.name} onBack={onBack} right={<>
        <IconBtn name={inWatchlist ? "starFill" : "star"} color={inWatchlist ? "var(--accent)" : "var(--text-2)"} onClick={onToggleWatch} />
        <IconBtn name="bell" onClick={() => onAlert(id)} />
      </>} />

      <div style={{ padding: "16px 16px 0" }}>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 12 }}>
          <AssetIcon asset={a} size={44} />
          <div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 30, fontWeight: 700, color: "var(--text)", letterSpacing: "-0.02em", lineHeight: 1 }}>{window.FMT.price(a.price, currency)}<span style={{ fontSize: 14, color: "var(--text-3)" }}>{a.unit}</span></div>
            <div style={{ marginTop: 6 }}><Change value={a.change24h} size={14} chip /></div>
          </div>
        </div>
      </div>

      {/* chart mode toggle */}
      <div style={{ display: "flex", justifyContent: "flex-end", padding: "12px 16px 0" }}>
        <div style={{ display: "inline-flex", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--chip-radius)", padding: 3, gap: 2 }}>
          {[["line", "Křivka"], ["candle", "Svíčky"]].map(([m, l]) => (
            <div key={m} className="press" onClick={() => setMode(m)} style={{ padding: "5px 12px", borderRadius: "calc(var(--chip-radius) - 3px)", cursor: "pointer", fontFamily: "var(--font-ui)", fontSize: 12.5, fontWeight: 600, background: mode === m ? "var(--accent)" : "transparent", color: mode === m ? "var(--accent-ink)" : "var(--text-3)" }}>{l}</div>
          ))}
        </div>
      </div>

      <div style={{ padding: "8px 12px 0", color: accentLine }}>
        <PriceChart series={series} color={mode === "line" ? accentLine : "var(--text)"} mode={mode} currency={currency} width={388} height={208} />
      </div>

      <div style={{ display: "flex", gap: 6, padding: "8px 16px 4px" }}>
        {RANGES.map((r) => (
          <div key={r} className="press" onClick={() => setRange(r)} style={{ flex: 1, textAlign: "center", padding: "8px 0", borderRadius: "var(--chip-radius)", cursor: "pointer", fontFamily: "var(--font-mono)", fontSize: 12.5, fontWeight: 600, background: range === r ? "var(--surface-2)" : "transparent", color: range === r ? "var(--text)" : "var(--text-3)", border: `1px solid ${range === r ? "var(--border-strong)" : "transparent"}` }}>{r}</div>
        ))}
      </div>

      {/* stats */}
      <div style={{ padding: "12px 16px 0", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        <StatTile label="24h max" value={window.FMT.price(dayHi, currency)} />
        <StatTile label="24h min" value={window.FMT.price(dayLo, currency)} />
        <StatTile label="Změna 7 d" value={window.FMT.pct(a.change7d)} sub="" />
        <StatTile label="Změna 30 d" value={window.FMT.pct(a.change30d)} />
        {a.marketCap != null
          ? <StatTile label="Tržní kap." value={window.FMT.compact(a.marketCap, currency)} />
          : <StatTile label="Kategorie" value={window.CAT_LABEL[a.category]} />}
        <StatTile label="Objem 24h" value={window.FMT.compact(a.price * (a.marketCap ? 8.4e6 : 4.1e6), currency)} />
      </div>

      <div style={{ display: "flex", gap: 10, padding: "16px 16px 24px" }}>
        <div className="press" onClick={() => onAlert(id)} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: 13, borderRadius: "var(--radius)", border: "1px solid var(--border-strong)", color: "var(--text)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 600, fontSize: 14 }}>
          <Icon name="bell" size={18} color="var(--text)" /> Alert
        </div>
        <div className="press" onClick={onToggleWatch} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, padding: 13, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 14 }}>
          <Icon name={inWatchlist ? "check" : "plus"} size={18} color="var(--accent-ink)" /> {inWatchlist ? "Ve watchlistu" : "Sledovat"}
        </div>
      </div>
    </div>
  );
}

// ── Fear & Greed detail ──────────────────────────────────────────────
function FngStat({ label, value }) {
  const col = window.DATA.fngColor(value);
  return (
    <div style={{ flex: 1, padding: "12px 8px", textAlign: "center", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)" }}>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 22, fontWeight: 700, color: col }}>{value}</div>
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 10.5, color: "var(--text-3)", marginTop: 2 }}>{label}</div>
    </div>
  );
}

function FearGreed({ fng, onBack }) {
  const col = window.DATA.fngColor(fng.value);
  return (
    <div>
      <TopBar title="Strach & chamtivost" onBack={onBack} />
      <div style={{ display: "flex", justifyContent: "center", padding: "20px 16px 4px" }}>
        <div style={{ color: "var(--text)" }}>
          <Gauge value={fng.value} size={240} label={window.DATA.fngLabel(fng.value)} color={col} />
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, padding: "12px 16px 0" }}>
        <FngStat label="Včera" value={fng.yesterday} />
        <FngStat label="Min. týden" value={fng.lastWeek} />
        <FngStat label="Min. měsíc" value={fng.lastMonth} />
        <FngStat label="Loni" value={fng.lastYear} />
      </div>

      <div style={{ padding: "20px 16px 0" }}>
        <SectionLabel style={{ marginBottom: 8 }}>Vývoj indexu</SectionLabel>
        <Card pad={14}>
          <HistoryArea values={fng.history} width={356} height={92} />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6, fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--text-3)" }}>
            <span>před 17 dny</span><span>dnes</span>
          </div>
        </Card>
      </div>

      <div style={{ padding: "20px 16px 0" }}>
        <SectionLabel style={{ marginBottom: 8 }}>Složení indexu</SectionLabel>
        <Card pad={4}>
          {fng.components.map((c, i) => (
            <div key={c.label} style={{ padding: "11px 12px", borderTop: i ? "1px solid var(--border)" : "none" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
                <span style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, color: "var(--text)" }}>{c.label} <span style={{ color: "var(--text-3)", fontSize: 11 }}>· {c.weight}</span></span>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 13.5, fontWeight: 600, color: window.DATA.fngColor(c.score) }}>{c.score}</span>
              </div>
              <div style={{ height: 6, borderRadius: 3, background: "var(--surface-2)", overflow: "hidden" }}>
                <div style={{ width: c.score + "%", height: "100%", background: window.DATA.fngColor(c.score), borderRadius: 3 }} />
              </div>
            </div>
          ))}
        </Card>
      </div>

      <div style={{ padding: "18px 16px 28px" }}>
        <p style={{ fontFamily: "var(--font-ui)", fontSize: 13, lineHeight: 1.6, color: "var(--text-2)", margin: 0 }}>
          Index měří náladu trhu na škále 0–100. Nízké hodnoty (strach) často značí příležitost k nákupu, vysoké hodnoty (chamtivost) zvýšené riziko korekce. Aktualizuje se každé 4 hodiny.
        </p>
      </div>
    </div>
  );
}

Object.assign(window, { Markets, AssetDetail, FearGreed, TopBar, IconBtn, AssetRow, Tabs, StatTile });
