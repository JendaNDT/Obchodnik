/* screens3.jsx — Onboarding, AppSettings, prázdné stavy, AddPosition, Skeleton, NotifBanner */

// ── Splash / Loading skeleton ────────────────────────────────────────
function SkeletonBlock({ w = "100%", h = 16, r = 6, mt = 0 }) {
  return <div style={{ width: w, height: h, borderRadius: r, background: "var(--surface-2)", marginTop: mt, flexShrink: 0 }} className="skel" />;
}

function SkeletonRow() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px" }}>
      <div style={{ width: 38, height: 38, borderRadius: 38, background: "var(--surface-2)", flexShrink: 0 }} className="skel" />
      <div style={{ flex: 1 }}>
        <SkeletonBlock w="60px" h={13} />
        <SkeletonBlock w="90px" h={11} mt={6} />
      </div>
      <div style={{ textAlign: "right" }}>
        <SkeletonBlock w="70px" h={13} />
        <SkeletonBlock w="44px" h={11} mt={6} />
      </div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div style={{ animation: "fadeUp .3s ease" }}>
      <div style={{ height: 56, borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", padding: "0 16px", gap: 10 }}>
        <SkeletonBlock w="90px" h={18} r={9} />
        <div style={{ flex: 1 }} />
        <SkeletonBlock w="32px" h={32} r={10} />
        <SkeletonBlock w="32px" h={32} r={10} />
      </div>
      <div style={{ padding: "14px 16px 4px" }}>
        <div style={{ height: 72, borderRadius: "var(--radius)", background: "var(--surface)", border: "1px solid var(--border)", padding: 14, display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 48, height: 48, borderRadius: 48, background: "var(--surface-2)" }} className="skel" />
          <div style={{ flex: 1 }}>
            <SkeletonBlock w="140px" h={11} />
            <SkeletonBlock w="80px" h={17} mt={6} />
          </div>
        </div>
      </div>
      <div style={{ padding: "12px 16px 4px", display: "flex", gap: 8 }}>
        {[60, 52, 58, 48, 44].map((w, i) => <SkeletonBlock key={i} w={w} h={32} r={9} />)}
      </div>
      {[1, 2, 3, 4, 5, 6].map((i) => <SkeletonRow key={i} />)}
    </div>
  );
}

function ErrorScreen({ onRetry }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 420, gap: 18, padding: "0 32px", textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: "var(--surface)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--down)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" />
        </svg>
      </div>
      <div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 17, fontWeight: 700, color: "var(--text)", marginBottom: 8 }}>Nepodařilo se načíst data</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, color: "var(--text-3)", lineHeight: 1.5 }}>Zkontroluj připojení k internetu a zkus to znovu.</div>
      </div>
      <div className="press" onClick={onRetry} style={{ padding: "13px 28px", borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 14 }}>Zkusit znovu</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>ERR_NETWORK_TIMEOUT · api.cryptowidget.app</div>
    </div>
  );
}

// ── Notification banner (top overlay) ───────────────────────────────
function NotifBanner({ asset, op, target, currency, onDismiss, onOpen }) {
  const a = window.DATA.byId[asset];
  if (!a) return null;
  const label = op === ">" ? "překročila" : "klesla pod";
  return (
    <div style={{
      position: "absolute", top: 44, left: 12, right: 12, zIndex: 50,
      background: "rgba(20,22,30,0.96)", border: "1px solid var(--border-strong)",
      borderRadius: 16, padding: "12px 14px", boxShadow: "0 8px 28px rgba(0,0,0,0.5)",
      animation: "slideDown .28s cubic-bezier(.2,.8,.2,1)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
        <AssetIcon asset={a} size={36} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, fontWeight: 700, color: "var(--text)" }}>
            CryptoWidget · Alert
          </div>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 12.5, color: "var(--text-2)", marginTop: 2 }}>
            <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: a.color }}>{a.ticker}</span> {label} <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{window.FMT.price(target, currency)}</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <div className="press" onClick={onOpen} style={{ padding: "5px 10px", borderRadius: 8, background: "var(--accent)", color: "var(--accent-ink)", fontFamily: "var(--font-ui)", fontWeight: 600, fontSize: 12, cursor: "pointer" }}>Otevřít</div>
          <div className="press" onClick={onDismiss} style={{ padding: 5, borderRadius: 8, cursor: "pointer" }}><Icon name="close" size={16} color="var(--text-3)" /></div>
        </div>
      </div>
    </div>
  );
}

// ── Onboarding ───────────────────────────────────────────────────────
const OB_STEPS = ["welcome", "pick", "notif", "done"];

function OnboardingDots({ step }) {
  const idx = OB_STEPS.indexOf(step);
  return (
    <div style={{ display: "flex", gap: 7, justifyContent: "center" }}>
      {OB_STEPS.slice(0, -1).map((_, i) => (
        <div key={i} style={{ height: 5, borderRadius: 3, background: i === idx ? "var(--accent)" : "var(--surface-2)", width: i === idx ? 20 : 5, transition: "width .25s ease, background .2s" }} />
      ))}
    </div>
  );
}

const POPULAR_ONBOARDING = ["BTC", "ETH", "SOL", "BNB", "XAU", "XAG", "BRENT", "SPX", "NDX", "DOGE"];

function Onboarding({ onFinish }) {
  const [step, setStep] = React.useState("welcome");
  const [picked, setPicked] = React.useState(["BTC", "ETH", "XAU"]);
  const [notifOn, setNotifOn] = React.useState(true);

  const toggle = (id) => setPicked((p) => p.includes(id) ? (p.length > 1 ? p.filter((x) => x !== id) : p) : [...p, id]);
  const next = () => setStep(OB_STEPS[OB_STEPS.indexOf(step) + 1]);

  if (step === "welcome") return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", alignItems: "center", justifyContent: "space-between", padding: "28px 28px 32px" }}>
      {/* logo */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 22 }}>
        <div style={{
          width: 88, height: 88, borderRadius: 28,
          background: "linear-gradient(145deg, var(--surface-2), var(--surface))",
          border: "1px solid var(--border-strong)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 12px 40px rgba(0,0,0,0.35)",
        }}>
          <div style={{ display: "flex", gap: 4, alignItems: "flex-end" }}>
            {[8, 14, 6, 11, 10].map((h, i) => (
              <div key={i} style={{ width: 6, height: h, borderRadius: 2, background: ["var(--accent)", "#16c784", "var(--accent)", "#a78bfa", "#f7931a"][i], opacity: 0.9 }} />
            ))}
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 30, fontWeight: 800, color: "var(--text)", letterSpacing: "-0.02em", lineHeight: 1 }}>CryptoWidget</div>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 15.5, color: "var(--text-3)", marginTop: 10, lineHeight: 1.5 }}>Krypto, kovy a komodity.<br />Vždy na ploše, vždy aktuální.</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, width: "100%", marginTop: 8 }}>
          {[
            { icon: "grid", text: "Widget na ploše s aktuálními cenami" },
            { icon: "chart", text: "Grafy a sledování vývoje aktiv" },
            { icon: "bolt", text: "Okamžité alerty na cílové ceny" },
          ].map((f) => (
            <div key={f.text} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 14px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)" }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: "var(--accent-soft)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Icon name={f.icon} size={18} color="var(--accent)" />
              </div>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "var(--text-2)" }}>{f.text}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ width: "100%", marginTop: 20 }}>
        <OnboardingDots step={step} />
        <div className="press" onClick={next} style={{ marginTop: 18, width: "100%", padding: 17, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", textAlign: "center", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 16 }}>Začít →</div>
      </div>
    </div>
  );

  if (step === "pick") return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", padding: "28px 20px 32px" }}>
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 24, fontWeight: 800, color: "var(--text)", letterSpacing: "-0.01em", lineHeight: 1.1 }}>Jaká aktiva<br />tě zajímají?</div>
      <div style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "var(--text-3)", marginTop: 8 }}>Vyber alespoň jedno — kdykoli změníš.</div>
      <div style={{ flex: 1, overflowY: "auto", margin: "18px -4px 0", padding: "0 4px", scrollbarWidth: "none" }}>
        {window.DATA.CATEGORIES.filter((c) => c.id !== "vse").map((cat) => {
          const items = POPULAR_ONBOARDING.map((id) => window.DATA.byId[id]).filter((a) => a && a.category === cat.id);
          if (!items.length) return null;
          return (
            <div key={cat.id} style={{ marginBottom: 14 }}>
              <SectionLabel style={{ marginBottom: 7 }}>{cat.label}</SectionLabel>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {items.map((a) => {
                  const on = picked.includes(a.id);
                  return (
                    <div key={a.id} className="press" onClick={() => toggle(a.id)} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 13px", borderRadius: "var(--chip-radius)", cursor: "pointer", background: on ? "var(--accent)" : "var(--surface)", color: on ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${on ? "var(--accent)" : "var(--border)"}`, fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 13 }}>
                      {on && <Icon name="check" size={14} color="var(--accent-ink)" />}
                      {a.ticker}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div style={{ marginBottom: 14 }}>
          <SectionLabel style={{ marginBottom: 7 }}>Komodity & indexy</SectionLabel>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {["BRENT", "NG", "WHEAT", "SPX", "NDX", "DAX"].map((id) => {
              const a = window.DATA.byId[id];
              const on = picked.includes(id);
              return (
                <div key={id} className="press" onClick={() => toggle(id)} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 13px", borderRadius: "var(--chip-radius)", cursor: "pointer", background: on ? "var(--accent)" : "var(--surface)", color: on ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${on ? "var(--accent)" : "var(--border)"}`, fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 13 }}>
                  {on && <Icon name="check" size={14} color="var(--accent-ink)" />}
                  {a.ticker}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div style={{ marginTop: 12 }}>
        <OnboardingDots step={step} />
        <div className="press" onClick={next} style={{ marginTop: 16, width: "100%", padding: 17, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", textAlign: "center", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 16 }}>Pokračovat ({picked.length} aktiv)</div>
      </div>
    </div>
  );

  if (step === "notif") return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", alignItems: "center", justifyContent: "space-between", padding: "40px 28px 32px" }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20, width: "100%" }}>
        <div style={{ width: 78, height: 78, borderRadius: 24, background: "var(--accent-soft)", border: `1px solid var(--accent)44`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="bell" size={34} color="var(--accent)" />
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 24, fontWeight: 800, color: "var(--text)", letterSpacing: "-0.01em" }}>Cenové alerty</div>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "var(--text-3)", marginTop: 10, lineHeight: 1.6 }}>Upozorníme tě, jakmile aktivum dosáhne tvé cílové ceny. Žádné neustálé sledování.</div>
        </div>
        {/* mock notif */}
        <div style={{ width: "100%", background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: 16, padding: "13px 14px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: "#f7931a22", border: "1px solid #f7931a44", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontSize: 10, fontWeight: 700, color: "#f7931a" }}>₿</div>
            <div>
              <div style={{ fontFamily: "var(--font-ui)", fontSize: 13, fontWeight: 700, color: "var(--text)" }}>CryptoWidget · Alert</div>
              <div style={{ fontFamily: "var(--font-ui)", fontSize: 12.5, color: "var(--text-2)" }}>BTC překročila <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>$70 000</span></div>
            </div>
            <div style={{ marginLeft: "auto", fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>právě teď</div>
          </div>
        </div>
        <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 8 }}>
          <div className="press" onClick={() => { setNotifOn(true); next(); }} style={{ width: "100%", padding: 16, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", textAlign: "center", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 15 }}>Zapnout oznámení</div>
          <div className="press" onClick={() => { setNotifOn(false); next(); }} style={{ width: "100%", padding: 14, borderRadius: "var(--radius)", textAlign: "center", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 500, fontSize: 14, color: "var(--text-3)" }}>Teď ne</div>
        </div>
      </div>
      <div style={{ width: "100%", marginTop: 8 }}><OnboardingDots step={step} /></div>
    </div>
  );

  if (step === "done") return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", alignItems: "center", justifyContent: "center", padding: "28px 28px 40px", gap: 20 }}>
      <div style={{ width: 82, height: 82, borderRadius: 82, background: "var(--up)18", border: "1px solid var(--up)44", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name="check" size={38} color="var(--up)" sw={2.4} />
      </div>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 26, fontWeight: 800, color: "var(--text)", letterSpacing: "-0.01em" }}>Vše nastaveno!</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 14, color: "var(--text-3)", marginTop: 10, lineHeight: 1.6 }}>Tvůj watchlist je připraven.<br />Přidej si widget na plochu.</div>
      </div>
      <div className="press" onClick={() => onFinish({ notifOn })} style={{ marginTop: 10, width: "100%", padding: 17, borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", textAlign: "center", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 16 }}>Přejít do aplikace →</div>
    </div>
  );
}

// ── App Settings ─────────────────────────────────────────────────────
function SettingsRow({ label, sub, right, onPress, sep = true }) {
  const inner = (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", cursor: onPress ? "pointer" : "default" }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 15, color: "var(--text)" }}>{label}</div>
        {sub && <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)", marginTop: 2 }}>{sub}</div>}
      </div>
      {right}
    </div>
  );
  return sep
    ? <div className={onPress ? "press row-sep" : "row-sep"} onClick={onPress}>{inner}</div>
    : <div className={onPress ? "press" : ""} onClick={onPress}>{inner}</div>;
}

function AppSettings({ accent, onBack, tweakTheme, setTweakTheme, tweakCurrency, setTweakCurrency, tweakDensity, setTweakDensity }) {
  const [notif, setNotif] = React.useState(true);
  const [unit, setUnit] = React.useState("USD");
  const [showThemeSheet, setShowThemeSheet] = React.useState(false);
  const [showCurrSheet, setShowCurrSheet] = React.useState(false);
  const [showAbout, setShowAbout] = React.useState(false);

  return (
    <div>
      <TopBar title="Nastavení" big onBack={onBack} />

      {/* profile */}
      <div style={{ padding: "18px 16px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
          <div style={{ width: 52, height: 52, borderRadius: 52, background: "var(--accent-soft)", border: `1px solid var(--accent)55`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontSize: 20, fontWeight: 700, color: "var(--accent)", flexShrink: 0 }}>CW</div>
          <div>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 16, fontWeight: 700, color: "var(--text)" }}>Můj účet</div>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 12.5, color: "var(--text-3)" }}>Synchronizace napříč zařízeními</div>
          </div>
          <div style={{ marginLeft: "auto" }}><Icon name="chevron" size={18} color="var(--text-3)" /></div>
        </div>
      </div>

      <SectionLabel style={{ padding: "22px 16px 6px" }}>Zobrazení</SectionLabel>
      <Card pad={0} style={{ margin: "0 16px" }}>
        <SettingsRow label="Téma" sub={tweakTheme === "terminal" ? "Terminal (výchozí)" : tweakTheme === "aurora" ? "Aurora — prémiový" : "Mono — minimalistický"} onPress={() => setShowThemeSheet(true)} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
        <SettingsRow label="Hustota" sub={tweakDensity} onPress={() => setTweakDensity(tweakDensity === "kompaktní" ? "běžná" : tweakDensity === "běžná" ? "vzdušná" : "kompaktní")} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
      </Card>

      <SectionLabel style={{ padding: "18px 16px 6px" }}>Měna & jednotky</SectionLabel>
      <Card pad={0} style={{ margin: "0 16px" }}>
        <SettingsRow label="Základní měna" sub={tweakCurrency === "USD" ? "USD — americký dolar" : "CZK — česká koruna"} onPress={() => setShowCurrSheet(true)} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
        <SettingsRow label="Množství" sub="Reálné jednotky (BTC, oz, bbl…)" right={<Switch on={true} onChange={() => {}} />} />
      </Card>

      <SectionLabel style={{ padding: "18px 16px 6px" }}>Oznámení</SectionLabel>
      <Card pad={0} style={{ margin: "0 16px" }}>
        <SettingsRow label="Cenové alerty" sub="Push oznámení při splnění podmínky" right={<Switch on={notif} onChange={setNotif} />} />
        <SettingsRow label="Denní přehled" sub="Souhrn trhu každý den v 8:00" right={<Switch on={false} onChange={() => {}} />} />
        <SettingsRow label="Extrémní pohyby" sub="Pokles nebo nárůst > 10 % za 24h" right={<Switch on={true} onChange={() => {}} />} />
      </Card>

      <SectionLabel style={{ padding: "18px 16px 6px" }}>Zdroj dat</SectionLabel>
      <Card pad={0} style={{ margin: "0 16px" }}>
        <SettingsRow label="Poskytovatel" sub="CoinGecko · Metals-API · Alpha Vantage" right={<span style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)" }}>FREE</span>} />
        <SettingsRow label="Frekvence aktualizace" sub="Každých 5 minut" right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
        <SettingsRow label="Obnovit data" onPress={() => {}} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
      </Card>

      <SectionLabel style={{ padding: "18px 16px 6px" }}>Aplikace</SectionLabel>
      <Card pad={0} style={{ margin: "0 16px" }}>
        <SettingsRow label="O aplikaci" sub="CryptoWidget v1.0.0" onPress={() => setShowAbout(true)} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
        <SettingsRow label="Ohodnotit na Google Play" onPress={() => {}} right={<Icon name="arrowUpRight" size={18} color="var(--text-3)" />} />
        <SettingsRow label="Obnovit onboarding" onPress={() => {}} right={<Icon name="chevron" size={18} color="var(--text-3)" />} />
      </Card>

      <div style={{ padding: "20px 0 32px", textAlign: "center" }}>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>CryptoWidget · v1.0.0 · © 2026</span>
      </div>

      {showThemeSheet && (
        <Sheet title="Téma" onClose={() => setShowThemeSheet(false)}>
          {[["terminal", "Terminal", "Ostrý a data-dense, modrá/šedá"], ["aurora", "Aurora", "Prémiový, zaoblený, indigový"], ["mono", "Mono", "Minimalistický, čistě monospace"]].map(([id, l, d]) => (
            <div key={id} className="press" onClick={() => { setTweakTheme(id); setShowThemeSheet(false); }} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 4px", borderTop: "1px solid var(--border)", cursor: "pointer" }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "var(--font-ui)", fontSize: 15, fontWeight: 600, color: "var(--text)" }}>{l}</div>
                <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)" }}>{d}</div>
              </div>
              {tweakTheme === id && <Icon name="check" size={18} color="var(--accent)" />}
            </div>
          ))}
        </Sheet>
      )}
      {showCurrSheet && (
        <Sheet title="Základní měna" onClose={() => setShowCurrSheet(false)}>
          {[["USD", "Americký dolar", "$"], ["CZK", "Česká koruna", "Kč"]].map(([id, l, s]) => (
            <div key={id} className="press" onClick={() => { setTweakCurrency(id); setShowCurrSheet(false); }} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 4px", borderTop: "1px solid var(--border)", cursor: "pointer" }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--surface-2)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--font-mono)", fontWeight: 700, color: "var(--text-2)", fontSize: 14, flexShrink: 0 }}>{s}</div>
              <div style={{ flex: 1 }}><div style={{ fontFamily: "var(--font-ui)", fontSize: 15, fontWeight: 600, color: "var(--text)" }}>{id}</div><div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-3)" }}>{l}</div></div>
              {tweakCurrency === id && <Icon name="check" size={18} color="var(--accent)" />}
            </div>
          ))}
        </Sheet>
      )}
      {showAbout && (
        <Sheet title="O aplikaci" onClose={() => setShowAbout(false)}>
          <div style={{ textAlign: "center", padding: "10px 0 20px" }}>
            <div style={{ width: 68, height: 68, borderRadius: 22, background: "var(--surface-2)", margin: "0 auto 12px", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ display: "flex", gap: 3, alignItems: "flex-end" }}>
                {[8, 14, 6, 11, 10].map((h, i) => <div key={i} style={{ width: 5, height: h, borderRadius: 2, background: ["var(--accent)", "#16c784", "var(--accent)", "#a78bfa", "#f7931a"][i] }} />)}
              </div>
            </div>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 18, fontWeight: 700, color: "var(--text)" }}>CryptoWidget</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--text-3)", marginTop: 4 }}>v1.0.0 · Android · CryptoWidget s.r.o.</div>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 13, color: "var(--text-2)", marginTop: 12, lineHeight: 1.6 }}>Krypto, drahé kovy, komodity a indexy na jednom místě. Navrženo pro denní sledování trhu.</div>
          </div>
        </Sheet>
      )}
    </div>
  );
}

// ── Add position (portfolio) sheet ───────────────────────────────────
function AddPositionSheet({ onClose, onSave }) {
  const [asset, setAsset] = React.useState("BTC");
  const [qty, setQty] = React.useState("");
  const [avg, setAvg] = React.useState("");
  const a = window.DATA.byId[asset];
  const val = a && qty && avg ? (parseFloat(qty) * a.price) : null;
  const cost = qty && avg ? (parseFloat(qty) * parseFloat(avg)) : null;
  const pl = val != null && cost ? val - cost : null;
  const plPct = pl != null && cost ? (pl / cost) * 100 : null;
  const pop = ["BTC", "ETH", "SOL", "BNB", "XAU", "DOGE", "BRENT", "SPX"];
  return (
    <Sheet title="Přidat pozici" onClose={onClose}>
      <SectionLabel style={{ marginBottom: 8 }}>Aktivum</SectionLabel>
      <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginBottom: 18 }}>
        {pop.map((id) => { const on = id === asset; return <div key={id} className="press" onClick={() => { setAsset(id); setAvg(""); }} style={{ padding: "7px 12px", borderRadius: "var(--chip-radius)", cursor: "pointer", fontFamily: "var(--font-mono)", fontWeight: 600, fontSize: 12.5, background: on ? "var(--accent)" : "var(--surface)", color: on ? "var(--accent-ink)" : "var(--text-2)", border: `1px solid ${on ? "var(--accent)" : "var(--border)"}` }}>{id}</div>; })}
      </div>
      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <SectionLabel style={{ marginBottom: 6 }}>Množství</SectionLabel>
          <input type="number" value={qty} onChange={(e) => setQty(e.target.value)} placeholder={a ? (a.price > 1000 ? "0.00" : "0.00") : "0"} style={{ width: "100%", background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-sm)", padding: "12px 13px", color: "var(--text)", fontFamily: "var(--font-mono)", fontSize: 16, fontWeight: 600, outline: "none" }} />
        </div>
        <div style={{ flex: 1 }}>
          <SectionLabel style={{ marginBottom: 6 }}>Nák. cena (USD)</SectionLabel>
          <input type="number" value={avg} onChange={(e) => setAvg(e.target.value)} placeholder={a ? window.FMT.price(a.price, "USD") : ""} style={{ width: "100%", background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-sm)", padding: "12px 13px", color: "var(--text)", fontFamily: "var(--font-mono)", fontSize: 16, fontWeight: 600, outline: "none" }} />
        </div>
      </div>
      {val != null && (
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          <div style={{ flex: 1, padding: "10px 12px", background: "var(--surface)", borderRadius: "var(--radius-sm)", border: "1px solid var(--border)" }}>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, color: "var(--text-3)" }}>Aktuální hodnota</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 600, color: "var(--text)", marginTop: 3 }}>{window.FMT.price(val, "USD", 2)}</div>
          </div>
          <div style={{ flex: 1, padding: "10px 12px", background: "var(--surface)", borderRadius: "var(--radius-sm)", border: "1px solid var(--border)" }}>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, color: "var(--text-3)" }}>Nerealizovaný zisk</div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 600, color: pl >= 0 ? "var(--up)" : "var(--down)", marginTop: 3 }}>{window.FMT.signedPrice(pl, "USD", 2)} ({window.FMT.pct(plPct)})</div>
          </div>
        </div>
      )}
      <div className="press" onClick={() => { if (qty && avg) { onSave({ id: asset, qty: parseFloat(qty), avg: parseFloat(avg) }); onClose(); } }} style={{ width: "100%", padding: 15, borderRadius: "var(--radius)", background: qty && avg ? "var(--accent)" : "var(--surface-2)", color: qty && avg ? "var(--accent-ink)" : "var(--text-3)", textAlign: "center", cursor: qty && avg ? "pointer" : "default", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 15 }}>Uložit pozici</div>
    </Sheet>
  );
}

// ── Empty states ─────────────────────────────────────────────────────
function EmptyWatchlist({ onSearch }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "60px 32px", gap: 16, textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: "var(--surface)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name="star" size={28} color="var(--text-3)" />
      </div>
      <div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 17, fontWeight: 700, color: "var(--text)" }}>Prázdný watchlist</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, color: "var(--text-3)", marginTop: 6, lineHeight: 1.5 }}>Přidej si aktiva, která chceš sledovat.</div>
      </div>
      <div className="press" onClick={onSearch} style={{ padding: "12px 22px", borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 14 }}>Hledat aktiva</div>
    </div>
  );
}

function EmptyPortfolio({ onAdd }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "50px 32px", gap: 16, textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: "var(--surface)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon name="wallet" size={28} color="var(--text-3)" />
      </div>
      <div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 17, fontWeight: 700, color: "var(--text)" }}>Žádné pozice</div>
        <div style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, color: "var(--text-3)", marginTop: 6, lineHeight: 1.5 }}>Zaznamenej svůj nákup a sleduj zisk nebo ztrátu v reálném čase.</div>
      </div>
      <div className="press" onClick={onAdd} style={{ padding: "12px 22px", borderRadius: "var(--radius)", background: "var(--accent)", color: "var(--accent-ink)", cursor: "pointer", fontFamily: "var(--font-ui)", fontWeight: 700, fontSize: 14 }}>Přidat první pozici</div>
    </div>
  );
}

Object.assign(window, {
  Onboarding, AppSettings, AddPositionSheet,
  NotifBanner, SkeletonBlock, SkeletonRow, LoadingScreen, ErrorScreen,
  EmptyWatchlist, EmptyPortfolio, Switch,
});
