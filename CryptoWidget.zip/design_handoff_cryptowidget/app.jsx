/* app.jsx — CryptoWidget v2: onboarding, settings, notif banner, loading, empty states */

const { useState, useEffect, useRef } = React;

// ── Dark Android status bar ──────────────────────────────────────────
function StatusBar({ light }) {
  const c = "#fff";
  return (
    <div style={{ height: 34, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 18px", position: "relative", flexShrink: 0 }}>
      <span style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, fontWeight: 600, color: c }}>9:30</span>
      <div style={{ position: "absolute", left: "50%", top: 8, transform: "translateX(-50%)", width: 9, height: 9, borderRadius: 9, background: "#000" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
        <svg width="15" height="12" viewBox="0 0 16 13"><path d="M1 9h2v3H1zM5 6h2v6H5zM9 3h2v9H9zM13 0h2v12h-2z" fill={c} /></svg>
        <svg width="15" height="12" viewBox="0 0 16 13"><path d="M8 11.5L.8 5.2a10 10 0 0114.4 0L8 11.5z" fill={c} /></svg>
        <svg width="22" height="12" viewBox="0 0 24 13"><rect x="1" y="1.5" width="19" height="10" rx="2.5" fill="none" stroke={c} strokeOpacity="0.6" /><rect x="2.5" y="3" width="13" height="7" rx="1" fill={c} /><rect x="21" y="4.5" width="1.6" height="4" rx="0.8" fill={c} /></svg>
      </div>
    </div>
  );
}

const NAV = [
  { id: "markets",   label: "Trh",      icon: "chart" },
  { id: "portfolio", label: "Portfolio", icon: "wallet" },
  { id: "fng",       label: "Index",     icon: "gauge" },
  { id: "alerts",    label: "Alerty",    icon: "bell" },
  { id: "settings",  label: "Nastavení", icon: "settings" },
];

function BottomNav({ tab, onTab, alertCount }) {
  return (
    <div style={{ flexShrink: 0, display: "flex", background: "var(--bg)", borderTop: "1px solid var(--border)", padding: "8px 6px 4px" }}>
      {NAV.map((n) => {
        const active = tab === n.id;
        const badge = n.id === "alerts" && alertCount > 0;
        return (
          <div key={n.id} className="press" onClick={() => onTab(n.id)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, cursor: "pointer", padding: "4px 0" }}>
            <div style={{ position: "relative", padding: "3px 16px", borderRadius: 16, background: active ? "var(--accent-soft)" : "transparent" }}>
              <Icon name={n.icon} size={22} color={active ? "var(--accent)" : "var(--text-3)"} sw={active ? 2 : 1.8} />
              {badge && <span style={{ position: "absolute", top: 1, right: 10, width: 7, height: 7, borderRadius: 7, background: "var(--accent)", border: "1.5px solid var(--bg)" }} />}
            </div>
            <span style={{ fontFamily: "var(--font-ui)", fontSize: 10.5, fontWeight: active ? 700 : 500, color: active ? "var(--accent)" : "var(--text-3)" }}>{n.label}</span>
          </div>
        );
      })}
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "terminal",
  "accent": "#3b82f6",
  "density": "běžná",
  "currency": "USD",
  "defaultChart": "line"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // ── app lifecycle state ──
  const [phase, setPhase] = useState("splash");      // splash | onboarding | home | app
  const [tab, setTab] = useState("markets");
  const [pushed, setPushed] = useState(null);        // {type, ...}

  // ── data state ──
  const [watchlist, setWatchlist] = useState(window.DATA.WATCHLIST.slice());
  const [holdings, setHoldings] = useState(window.DATA.HOLDINGS.map((h) => ({ ...h })));
  const [alerts, setAlerts] = useState(window.DATA.ALERTS.map((a) => ({ ...a })));

  // ── UI state ──
  const [alertSheet, setAlertSheet]     = useState(false);
  const [addPoSheet, setAddPoSheet]     = useState(false);
  const [presetAsset, setPresetAsset]   = useState(null);
  const [widgetConfig, setWidgetConfig] = useState({ assets: ["BTC", "ETH", "SOL", "XAU", "SPX"], showFng: true });
  const [notifBanner, setNotifBanner]   = useState(null); // {asset,op,target}
  const [scale, setScale]               = useState(1);
  const scrollRef = useRef(null);
  const fng = window.DATA.FNG;

  // ── splash → onboarding ──
  useEffect(() => {
    const t = setTimeout(() => setPhase("onboarding"), 1200);
    return () => clearTimeout(t);
  }, []);

  // ── scale-to-fit ──
  useEffect(() => {
    const W = 412, H = 880;
    const fit = () => {
      const s = Math.min((window.innerWidth - 24) / W, (window.innerHeight - 24) / H, 1);
      setScale(s > 0 ? s : 1);
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  // ── reset scroll ──
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [tab, pushed, phase]);

  // ── demo notif trigger (fires once after entering app) ──
  const notifFired = useRef(false);
  useEffect(() => {
    if (phase !== "app" || notifFired.current) return;
    notifFired.current = true;
    const id = setTimeout(() => {
      setNotifBanner({ asset: "BTC", op: ">", target: 70000 });
      setTimeout(() => setNotifBanner(null), 5000);
    }, 3200);
    return () => clearTimeout(id);
  }, [phase]);

  // ── theme sync (tweaks → settings also reads these) ──
  const rootVars = { "--accent": t.accent, "--accent-ink": "#ffffff", "--accent-soft": t.accent + "22" };

  // ── actions ──
  const openApp   = ()  => { setPhase("app"); setTab("markets"); setPushed(null); };
  const goHome    = ()  => { setPhase("home"); setPushed(null); };
  const back      = ()  => setPushed(null);
  const openAsset = (id) => setPushed({ type: "detail", id });
  const goSearch  = ()  => setPushed({ type: "search" });
  const openAlertFor = (id) => { setPresetAsset(id); setTab("alerts"); setPushed(null); setAlertSheet(true); };

  const toggleWatch = (id) => setWatchlist((w) => w.includes(id) ? w.filter((x) => x !== id) : [...w, id]);
  const addAlert    = (d)  => setAlerts((al) => [{ id: Date.now(), asset: d.asset, op: d.op, target: d.target, active: true, triggered: false }, ...al]);
  const toggleAlert = (id) => setAlerts((al) => al.map((a) => a.id === id ? { ...a, active: !a.active } : a));
  const delAlert    = (id) => setAlerts((al) => al.filter((a) => a.id !== id));
  const addHolding  = (h)  => setHoldings((hs) => {
    const ex = hs.find((x) => x.id === h.id);
    if (ex) {
      const totalQty = ex.qty + h.qty;
      const newAvg   = (ex.qty * ex.avg + h.qty * h.avg) / totalQty;
      return hs.map((x) => x.id === h.id ? { ...x, qty: totalQty, avg: newAvg } : x);
    }
    return [...hs, h];
  });

  const activeAlerts = alerts.filter((a) => a.active).length;

  // ── render screens ──
  let screen;
  if (pushed?.type === "detail") {
    screen = <AssetDetail id={pushed.id} currency={t.currency} defaultChart={t.defaultChart} inWatchlist={watchlist.includes(pushed.id)} onBack={back} onToggleWatch={() => toggleWatch(pushed.id)} onAlert={openAlertFor} />;
  } else if (pushed?.type === "search") {
    screen = <Search watchlist={watchlist} currency={t.currency} onBack={back} onOpenAsset={openAsset} onToggleWatch={toggleWatch} />;
  } else if (tab === "markets") {
    screen = <Markets watchlist={watchlist} currency={t.currency} density={t.density} onOpenAsset={openAsset} onSearch={goSearch} onAlerts={() => setTab("alerts")} onFng={() => setTab("fng")} fng={fng} />;
  } else if (tab === "portfolio") {
    screen = <PortfolioScreen holdings={holdings} currency={t.currency} density={t.density} onOpenAsset={openAsset} onAdd={() => setAddPoSheet(true)} />;
  } else if (tab === "fng") {
    screen = <FearGreed fng={fng} onBack={() => setTab("markets")} />;
  } else if (tab === "alerts") {
    screen = <Alerts alerts={alerts} currency={t.currency} presetAsset={presetAsset} onBack={() => setTab("markets")} onToggle={toggleAlert} onDelete={delAlert} onAdd={addAlert} openSheet={alertSheet} setOpenSheet={setAlertSheet} />;
  } else if (tab === "settings") {
    screen = <AppSettings accent={t.accent} onBack={() => setTab("markets")} tweakTheme={t.theme} setTweakTheme={(v) => setTweak("theme", v)} tweakCurrency={t.currency} setTweakCurrency={(v) => setTweak("currency", v)} tweakDensity={t.density} setTweakDensity={(v) => setTweak("density", v)} />;
  }

  const showNav  = phase === "app" && !pushed;
  const showHome = phase === "home";

  // ── SPLASH ──
  const isSplash = phase === "splash";
  const isOnboarding = phase === "onboarding";

  return (
    <div data-theme={t.theme} style={{ ...rootVars, width: "100vw", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#000", overflow: "hidden" }}>
      <div style={{ transform: `scale(${scale})`, transformOrigin: "center center" }}>
        {/* phone bezel */}
        <div style={{ width: 412, height: 880, borderRadius: 44, padding: 10, background: "linear-gradient(145deg,#23262c,#0c0d10)", boxShadow: "0 40px 90px rgba(0,0,0,0.6), inset 0 0 2px rgba(255,255,255,0.3)" }}>
          <div data-screen-label="CryptoWidget" style={{ width: "100%", height: "100%", borderRadius: 36, overflow: "hidden", background: "var(--bg)", display: "flex", flexDirection: "column", position: "relative" }}>

            {/* Splash */}
            {isSplash && (
              <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "var(--bg)", zIndex: 60, gap: 18 }}>
                <div style={{ width: 82, height: 82, borderRadius: 26, background: "linear-gradient(145deg,var(--surface-2),var(--surface))", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 16px 48px rgba(0,0,0,0.4)" }}>
                  <div style={{ display: "flex", gap: 4, alignItems: "flex-end" }}>
                    {[9, 15, 7, 12, 11].map((h, i) => <div key={i} style={{ width: 6, height: h, borderRadius: 2, background: [t.accent, "#16c784", t.accent, "#a78bfa", "#f7931a"][i], opacity: 0.92 }} />)}
                  </div>
                </div>
                <div style={{ fontFamily: "var(--font-ui)", fontSize: 22, fontWeight: 800, color: "var(--text)", letterSpacing: "-0.02em" }}>CryptoWidget</div>
                <div style={{ position: "absolute", bottom: 40, fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--text-3)" }}>Načítám data…</div>
              </div>
            )}

            {/* Onboarding */}
            {isOnboarding && (
              <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column", animation: "fadeUp .3s ease" }}>
                <StatusBar />
                <div style={{ flex: 1, overflow: "hidden" }}>
                  <Onboarding onFinish={() => { setPhase("home"); }} />
                </div>
              </div>
            )}

            {/* Main app (home screen or app) */}
            {(phase === "home" || phase === "app") && (
              <>
                <StatusBar />
                <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", overflowX: "hidden", position: "relative" }} className="appscroll">
                  {showHome
                    ? <HomeScreen accent={t.accent} currency={t.currency} fng={fng} widgetConfig={widgetConfig} onOpen={openApp} onOpenWidgetSettings={() => { setPhase("app"); setTab("settings"); }} />
                    : screen}
                </div>

                {/* Add position sheet */}
                {addPoSheet && (
                  <div style={{ position: "absolute", inset: 0, zIndex: 40 }}>
                    <AddPositionSheet onClose={() => setAddPoSheet(false)} onSave={(h) => { addHolding(h); setAddPoSheet(false); }} />
                  </div>
                )}

                {showNav && <BottomNav tab={tab} onTab={(id) => { setTab(id); setPushed(null); }} alertCount={activeAlerts} />}

                {/* Gesture pill */}
                <div style={{ flexShrink: 0, height: 22, display: "flex", alignItems: "center", justifyContent: "center", background: showNav ? "var(--bg)" : "transparent", position: phase === "app" ? "relative" : "absolute", bottom: 0, left: 0, right: 0, zIndex: 30 }}>
                  <div className="press" onClick={goHome} title="Domů" style={{ width: 120, height: 4.5, borderRadius: 3, background: "#fff", opacity: 0.55, cursor: "pointer" }} />
                </div>

                {/* Notification banner */}
                {notifBanner && (
                  <NotifBanner asset={notifBanner.asset} op={notifBanner.op} target={notifBanner.target} currency={t.currency} onDismiss={() => setNotifBanner(null)} onOpen={() => { setNotifBanner(null); openAsset(notifBanner.asset); if (phase !== "app") setPhase("app"); }} />
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <TweaksPanel>
        <TweakSection label="Styl" />
        <TweakRadio label="Téma" value={t.theme} options={["terminal", "aurora", "mono"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Akcent" value={t.accent} options={["#3b82f6", "#16c784", "#f7931a", "#a78bfa"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Rozložení" />
        <TweakRadio label="Hustota" value={t.density} options={["kompaktní", "běžná", "vzdušná"]} onChange={(v) => setTweak("density", v)} />
        <TweakSection label="Data" />
        <TweakRadio label="Měna" value={t.currency} options={["USD", "CZK"]} onChange={(v) => setTweak("currency", v)} />
        <TweakRadio label="Výchozí graf" value={t.defaultChart} options={["line", "candle"]} onChange={(v) => setTweak("defaultChart", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
