/* charts.jsx — SVG charts: Sparkline, PriceChart (line/candle), Gauge, HistoryArea */

// ── Sparkline: tiny line, optional area fill ─────────────────────────
function Sparkline({ closes, color = "#3b82f6", width = 72, height = 26, fill = true, sw = 1.6 }) {
  const min = Math.min(...closes), max = Math.max(...closes);
  const span = max - min || 1;
  const n = closes.length;
  const x = (i) => (i / (n - 1)) * width;
  const y = (v) => height - ((v - min) / span) * (height - sw) - sw / 2;
  const line = closes.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;
  const gid = "spg-" + color.replace(/[^a-z0-9]/gi, "");
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: "block", overflow: "visible" }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.28" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={area} fill={`url(#${gid})`} />}
      <path d={line} fill="none" stroke={color} strokeWidth={sw} strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

// ── PriceChart: full chart with gridlines + axis labels ──────────────
function PriceChart({ series, color = "#3b82f6", width = 372, height = 200, mode = "line", currency = "USD", up = true }) {
  const padT = 12, padB = 22, padR = 0, padL = 0;
  const innerH = height - padT - padB;
  const W = width - padL - padR;
  const closes = series.closes;
  const candles = series.candles;
  const lo = series.min, hi = series.max;
  const span = hi - lo || 1;
  const ax = (i, n) => padL + (i / (n - 1)) * W;
  const ay = (v) => padT + innerH - ((v - lo) / span) * innerH;
  const gridLevels = 4;
  const grid = [];
  for (let g = 0; g <= gridLevels; g++) {
    const v = lo + (span * g) / gridLevels;
    grid.push({ y: ay(v), v });
  }
  const UP = "#16c784", DOWN = "#ea3943";
  const gid = "pcg-" + color.replace(/[^a-z0-9]/gi, "");

  let body;
  if (mode === "candle") {
    const step = W / candles.length;
    const bw = Math.max(2, step * 0.6);
    body = candles.map((k, i) => {
      const cx = padL + step * i + step / 2;
      const isUp = k.c >= k.o;
      const col = isUp ? UP : DOWN;
      const yo = ay(k.o), yc = ay(k.c), yh = ay(k.h), yl = ay(k.l);
      const top = Math.min(yo, yc);
      const bh = Math.max(1, Math.abs(yc - yo));
      return (
        <g key={i}>
          <line x1={cx} x2={cx} y1={yh} y2={yl} stroke={col} strokeWidth="1" />
          <rect x={cx - bw / 2} y={top} width={bw} height={bh} fill={col} />
        </g>
      );
    });
  } else {
    const n = closes.length;
    const line = closes.map((v, i) => `${i === 0 ? "M" : "L"}${ax(i, n).toFixed(1)},${ay(v).toFixed(1)}`).join(" ");
    const area = `${line} L${padL + W},${padT + innerH} L${padL},${padT + innerH} Z`;
    body = (
      <g>
        <path d={area} fill={`url(#${gid})`} />
        <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        <circle cx={ax(n - 1, n)} cy={ay(closes[n - 1])} r="3.2" fill={color} />
      </g>
    );
  }

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: "block", overflow: "visible" }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {grid.map((g, i) => (
        <g key={i}>
          <line x1={padL} x2={padL + W} y1={g.y} y2={g.y} stroke="currentColor" strokeOpacity="0.07" strokeWidth="1" />
          <text x={padL + 2} y={g.y - 4} fontSize="9.5" fill="currentColor" fillOpacity="0.34" fontFamily="var(--font-mono)">
            {window.FMT ? window.FMT.price(g.v, currency, window.FMT.decimalsFor(g.v)) : g.v.toFixed(2)}
          </text>
        </g>
      ))}
      {body}
    </svg>
  );
}

// ── Gauge: Fear & Greed semicircle ───────────────────────────────────
function polar(cx, cy, r, deg) {
  const a = (deg * Math.PI) / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}
function arcPath(cx, cy, r, startDeg, endDeg) {
  const s = polar(cx, cy, r, startDeg);
  const e = polar(cx, cy, r, endDeg);
  const large = endDeg - startDeg > 180 ? 1 : 0;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
}
function Gauge({ value, size = 220, label, color }) {
  const cx = size / 2, cy = size / 2, r = size / 2 - 16;
  const segs = [
    { from: 0, to: 25, c: "#ef4444" },
    { from: 25, to: 45, c: "#f59e0b" },
    { from: 45, to: 55, c: "#eab308" },
    { from: 55, to: 75, c: "#84cc16" },
    { from: 75, to: 100, c: "#22c55e" },
  ];
  const toDeg = (v) => 180 + (v / 100) * 180;
  const needleDeg = toDeg(value);
  const np = polar(cx, cy, r - 18, needleDeg);
  const height = cy + 14;
  return (
    <svg width={size} height={height} viewBox={`0 0 ${size} ${height}`} style={{ display: "block" }}>
      {segs.map((s, i) => (
        <path key={i} d={arcPath(cx, cy, r, toDeg(s.from), toDeg(s.to))}
          fill="none" stroke={s.c} strokeWidth="14" strokeLinecap="butt" opacity="0.92" />
      ))}
      {/* needle */}
      <line x1={cx} y1={cy} x2={np.x} y2={np.y} stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <circle cx={cx} cy={cy} r="6" fill="currentColor" />
      <text x={cx} y={cy - 18} textAnchor="middle" fontSize={size * 0.26} fontWeight="700"
        fill={color} fontFamily="var(--font-mono)">{value}</text>
      <text x={cx} y={cy + 2} textAnchor="middle" fontSize="13" fill="currentColor" fillOpacity="0.6"
        fontFamily="var(--font-ui)">{label}</text>
    </svg>
  );
}

// ── HistoryArea: small area chart for FNG history ────────────────────
function HistoryArea({ values, width = 372, height = 90 }) {
  const min = Math.min(...values), max = Math.max(...values);
  const span = max - min || 1;
  const n = values.length;
  const x = (i) => (i / (n - 1)) * width;
  const y = (v) => height - ((v - min) / span) * (height - 8) - 4;
  const line = values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: "block" }}>
      <defs>
        <linearGradient id="fngha" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#84cc16" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#84cc16" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#fngha)" />
      <path d={line} fill="none" stroke="#84cc16" strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
    </svg>
  );
}

Object.assign(window, { Sparkline, PriceChart, Gauge, HistoryArea });
