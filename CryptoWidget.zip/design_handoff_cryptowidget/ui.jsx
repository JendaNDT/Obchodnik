/* ui.jsx — shared presentational components for CryptoWidget */

const CAT_LABEL = { krypto: "Krypto", kovy: "Kovy", komodity: "Komodity", indexy: "Indexy" };

// Colored disc with ticker monogram
function AssetIcon({ asset, size = 38 }) {
  const mono = asset.ticker.length > 4 ? asset.ticker.slice(0, 3) : asset.ticker.slice(0, 1);
  return (
    <div style={{
      width: size, height: size, borderRadius: size, flexShrink: 0,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: asset.color + "22", border: `1px solid ${asset.color}55`,
      color: asset.color, fontFamily: "var(--font-mono)", fontWeight: 600,
      fontSize: mono.length > 1 ? size * 0.3 : size * 0.42, letterSpacing: "-0.02em",
    }}>{mono}</div>
  );
}

function Arrow({ up, size = 10, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 10 10" style={{ flexShrink: 0 }}>
      <path d={up ? "M5 1.5 L9 7 L1 7 Z" : "M5 8.5 L9 3 L1 3 Z"} fill={color} />
    </svg>
  );
}

// Colored % change, optionally with arrow / chip
function Change({ value, chip = false, arrow = true, size = 14, mono = true }) {
  const up = value >= 0;
  const col = up ? "var(--up)" : "var(--down)";
  const inner = (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4, whiteSpace: "nowrap",
      color: col, fontSize: size, fontWeight: 600,
      fontFamily: mono ? "var(--font-mono)" : "var(--font-ui)",
    }}>
      {arrow && <Arrow up={up} color={col} size={size * 0.7} />}
      {window.FMT.pct(value)}
    </span>
  );
  if (!chip) return inner;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center",
      background: (up ? "var(--up)" : "var(--down)") + "1f",
      borderRadius: "var(--chip-radius)", padding: "3px 8px",
    }}>{inner}</span>
  );
}

function Card({ children, style, onClick, pad = 16 }) {
  return (
    <div onClick={onClick} style={{
      background: "var(--surface)", border: "1px solid var(--border)",
      borderRadius: "var(--radius)", padding: pad, ...style,
    }}>{children}</div>
  );
}

// Section label, small uppercase mono
function SectionLabel({ children, style }) {
  return (
    <div style={{
      fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.12em",
      textTransform: "uppercase", color: "var(--text-3)", fontWeight: 600, ...style,
    }}>{children}</div>
  );
}

// Generic icon set (stroke), 24px grid
function Icon({ name, size = 22, color = "currentColor", sw = 1.8 }) {
  const p = { fill: "none", stroke: color, strokeWidth: sw, strokeLinecap: "round", strokeLinejoin: "round" };
  const paths = {
    search: <><circle cx="11" cy="11" r="7" {...p} /><line x1="16.5" y1="16.5" x2="21" y2="21" {...p} /></>,
    bell: <><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z" {...p} /><path d="M10 20a2 2 0 0 0 4 0" {...p} /></>,
    chart: <><path d="M4 19V5M4 19h16" {...p} /><path d="M7 15l3-4 3 2 4-6" {...p} /></>,
    wallet: <><rect x="3" y="6" width="18" height="13" rx="2.5" {...p} /><path d="M3 10h18" {...p} /><circle cx="16.5" cy="13.5" r="1.3" fill={color} stroke="none" /></>,
    gauge: <><path d="M4 18a8 8 0 1 1 16 0" {...p} /><path d="M12 18l4-5" {...p} /></>,
    settings: <><circle cx="12" cy="12" r="3" {...p} /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" {...p} /></>,
    plus: <><line x1="12" y1="5" x2="12" y2="19" {...p} /><line x1="5" y1="12" x2="19" y2="12" {...p} /></>,
    back: <><path d="M15 5l-7 7 7 7" {...p} /></>,
    star: <><path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.9 6.7 19.5l1.2-6L3.4 9.3l6-.7L12 3Z" {...p} /></>,
    starFill: <><path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.9 6.7 19.5l1.2-6L3.4 9.3l6-.7L12 3Z" fill={color} stroke={color} strokeWidth={sw} strokeLinejoin="round" /></>,
    check: <><path d="M5 12l4.5 4.5L19 7" {...p} /></>,
    close: <><path d="M6 6l12 12M18 6L6 18" {...p} /></>,
    chevron: <><path d="M9 6l6 6-6 6" {...p} /></>,
    dots: <><circle cx="12" cy="5" r="1.4" fill={color} stroke="none" /><circle cx="12" cy="12" r="1.4" fill={color} stroke="none" /><circle cx="12" cy="19" r="1.4" fill={color} stroke="none" /></>,
    trash: <><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" {...p} /></>,
    bolt: <><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8Z" {...p} /></>,
    filter: <><path d="M3 5h18M6 12h12M10 19h4" {...p} /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5" {...p} /><rect x="14" y="3" width="7" height="7" rx="1.5" {...p} /><rect x="3" y="14" width="7" height="7" rx="1.5" {...p} /><rect x="14" y="14" width="7" height="7" rx="1.5" {...p} /></>,
    arrowUpRight: <><path d="M7 17L17 7M9 7h8v8" {...p} /></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: "block", flexShrink: 0 }}>
      {paths[name] || null}
    </svg>
  );
}

// Pressable row that gives subtle feedback
function Press({ children, onClick, style }) {
  return (
    <div onClick={onClick} className="press" style={{ cursor: "pointer", ...style }}>{children}</div>
  );
}

Object.assign(window, { AssetIcon, Change, Arrow, Card, SectionLabel, Icon, Press, CAT_LABEL });
